package com.cognizant.service.impl;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.entities.*;
import com.cognizant.exception.BudgetAlreadyExistsException;
import com.cognizant.exception.InvalidBudgetException;
import com.cognizant.exception.InvalidGradeException;
import com.cognizant.exception.InvalidHotelStarRatingException;
import com.cognizant.repository.TravelBudgetAllocationRepository;
import com.cognizant.service.TravelBudgetAllocationService;
import com.cognizant.utilities.mapper.TravelBudgetAllocationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.util.Optional;

/**
 * Business Service implementing the TravelBudgetAllocationService interface for managing budget
 */
@Service
public class TravelBudgetAllocationServiceImpl implements TravelBudgetAllocationService {

    private final TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    private final TravelBudgetAllocationMapper travelBudgetAllocationMapper;

    /**
     * Constructs a new TravelBudgetAllocationServiceImpl with the specified dependencies
     * @param travelBudgetAllocationRepository The repository for accessing budget data
     * @param travelBudgetAllocationMapper The mapper for mapping between DTOs and entities
     */
    @Autowired
    public TravelBudgetAllocationServiceImpl(TravelBudgetAllocationRepository travelBudgetAllocationRepository, TravelBudgetAllocationMapper travelBudgetAllocationMapper) {
        this.travelBudgetAllocationRepository = travelBudgetAllocationRepository;
        this.travelBudgetAllocationMapper = travelBudgetAllocationMapper;
    }

    /**
     * Retrieves the budget information of the given travel request
     * @param travelRequestId ID of the travel request whose budget we have to retrieve
     * @return DTO representing the travel budget allocation if found
     */
    @Override
    public TravelBudgetAllocationDTO getBudgetAllocationsForTravelRequest(int travelRequestId) {
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRequestId(travelRequestId);
        Optional<TravelBudgetAllocation> travelBudgetAllocation = travelBudgetAllocationRepository.findByTravelRequest(travelRequest);
        if(travelBudgetAllocation.isEmpty()){
            throw new InvalidDataAccessApiUsageException("Travel Request do not exist for"+travelRequest);
        }else {
            return travelBudgetAllocationMapper.toDTO(travelBudgetAllocation.get());
        }
    }

    /**
     * Assigning the budget after the validation done
     * @param updateTravelRequestDTO the details of the travel request
     * @throws InvalidHotelStarRatingException if hotel star do not meet constraints
     * @throws InvalidBudgetException if budget/day do not meet constraints
     * @throws BudgetAlreadyExistsException if budget for the travel request already exists
     */
    @Override
    public void assignBudget(UpdateTravelRequestDTO updateTravelRequestDTO) throws InvalidHotelStarRatingException, InvalidBudgetException, InvalidGradeException, BudgetAlreadyExistsException{
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRequestId(updateTravelRequestDTO.getRequestId());
        Optional<TravelBudgetAllocation> checkIfTravelBudgetAllocationExists = travelBudgetAllocationRepository.findByTravelRequest(travelRequest);
        if(checkIfTravelBudgetAllocationExists.isPresent()){
            throw new BudgetAlreadyExistsException("Budget already exists for the Travel Request ID "+updateTravelRequestDTO.getRequestId());
        } else{
            validateHotelStarRating(updateTravelRequestDTO.getRole(),updateTravelRequestDTO.getApprovedHotelStarRating());
            validateBudget(updateTravelRequestDTO.getBudgetPerDay(), updateTravelRequestDTO.getGrade());

            TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
            travelBudgetAllocation.setTravelRequest(travelRequest);
            travelBudgetAllocation.setApprovedBudget(updateTravelRequestDTO.getApprovedBudget());
            travelBudgetAllocation.setApprovedModeOfTravel(updateTravelRequestDTO.getApprovedModeOfTravel());
            travelBudgetAllocation.setApprovedHotelStarRating(updateTravelRequestDTO.getApprovedHotelStarRating());

            travelBudgetAllocationRepository.save(travelBudgetAllocation);
        }
    }

    @Override
    public int calculateBudget(TravelRequestDTO travelRequestDTO){
        int totalDays = (int) ChronoUnit.DAYS.between(travelRequestDTO.getFromDate(),travelRequestDTO.getToDate());
        return totalDays * Math.abs(travelRequestDTO.getBudgetPerDay());
    }

    /**
     * Helper method to validate if Hotel assigned is according to the role
     * @param role Designation of the employee
     * @param rating Rating of the Hotel assigned
     * @throws InvalidHotelStarRatingException if the hotel assigned is not according to the role
     */
    public void validateHotelStarRating(Role role, HotelStarRating rating) throws InvalidHotelStarRatingException{
        if(role == Role.HR){
            if(HotelStarRating.STAR_3.equals(rating)){
                throw new InvalidHotelStarRatingException("HR can only stay in 5-star or 7-star hotels");
            }
        } else {
            if(HotelStarRating.STAR_7.equals(rating)){
                throw new InvalidHotelStarRatingException("Other employees can only stay in 3-star or 5-star hotels");
            }
        }
    }

    /**
     * Helper method to validate if budget is according to the grade of the employee
     * @param budgetPerDay The budget assigned to the travel request
     * @param grade The grade of the employee
     * @throws InvalidBudgetException if budget is not according to the grade
     * @throws InvalidGradeException if grade given is invalid
     */
    public void validateBudget(int budgetPerDay, Grade grade) throws InvalidBudgetException, InvalidGradeException{
        switch (grade){
            case GRADE_1:
                if(budgetPerDay>10000){
                    throw new InvalidBudgetException("Grade1 budget per day cannot exceed 10000");
                }
                break;

            case GRADE_2:
                if(budgetPerDay>12500){
                    throw new InvalidBudgetException("Grade2 budget per day cannot exceed 12500");
                }
                break;

            case GRADE_3:
                if(budgetPerDay>15000){
                    throw new InvalidBudgetException("Grade3 budget per day cannot exceed 15000");
                }
                break;

            default:
                throw new InvalidGradeException("Invalid Grade");
        }
    }

}
