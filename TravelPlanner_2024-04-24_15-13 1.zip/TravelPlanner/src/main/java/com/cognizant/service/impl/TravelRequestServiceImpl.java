package com.cognizant.service.impl;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.entities.*;
import com.cognizant.exception.*;
import com.cognizant.repository.TravelBudgetAllocationRepository;
import com.cognizant.repository.TravelRequestRepository;
import com.cognizant.service.TravelRequestService;
import com.cognizant.utilities.mapper.TravelRequestDetailsMapper;
import com.cognizant.utilities.mapper.TravelRequestMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Business Service implementing the TravelRequestService interface for managing travel requests
 */
@Service
public class TravelRequestServiceImpl implements TravelRequestService {

    private final TravelRequestRepository travelRequestRepository;
    private final TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    private final TravelRequestMapper travelRequestMapper;
    private final TravelRequestDetailsMapper travelRequestDetailsMapper;
    private final TravelBudgetAllocationServiceImpl travelBudgetAllocationService;
    private static final String TRAVEL_REQUEST_NOT_FOUND_EXCEPTION_MESSAGE = "Travel Request Not Found of Id: ";

    /**
     * Constructs a new TravelRequestServiceImpl with the specified dependencies
     * @param travelRequestRepository The repository for accessing travel request data
     * @param travelRequestMapper The mapper for mapping between DTOs and entities
     * @param travelRequestDetailsMapper The mapper for mapping between DTOs and entities
     * @param travelBudgetAllocationService The repository for accessing the budget info
     */
    @Autowired
    public TravelRequestServiceImpl(TravelRequestRepository travelRequestRepository, TravelBudgetAllocationRepository travelBudgetAllocationRepository, TravelRequestMapper travelRequestMapper, TravelRequestDetailsMapper travelRequestDetailsMapper, TravelBudgetAllocationServiceImpl travelBudgetAllocationService) {
        this.travelRequestRepository = travelRequestRepository;
        this.travelBudgetAllocationRepository = travelBudgetAllocationRepository;
        this.travelRequestMapper = travelRequestMapper;
        this.travelRequestDetailsMapper = travelRequestDetailsMapper;
        this.travelBudgetAllocationService = travelBudgetAllocationService;
    }

    /**
     * Adds a new travel request and obtains a travel request ID
     * @param travelRequestDTO DTO that carries information of the travel request
     * @return The ID of the newly added travel request
     * @throws InvalidDateException date is invalid if from date is lesser than present date or to date is lesser than from date
     * @throws InvalidPriorityException throws if Priority and total days do not meet the constraints
     */
    @Override
    public TravelRequestDTO addTravelRequest(TravelRequestDTO travelRequestDTO) throws InvalidDateException, InvalidPriorityException {
        //to check if to_date is less than from_date and from_date is not less than present date
        validateDate(travelRequestDTO.getFromDate(),travelRequestDTO.getToDate());
        //to check if Priority and Total Days fulfills the constraints
        validatePriority(travelRequestDTO.getFromDate(), travelRequestDTO.getToDate(), travelRequestDTO.getPriority());
        //mapping the travelRequest entity to DTO
        TravelRequest travelRequest = travelRequestMapper.toEntity(travelRequestDTO);
        travelRequest.setRequestStatus(RequestStatus.NEW);
        travelRequest.setRequestRaisedOn(LocalDate.now());
        TravelRequest addedTravelRequest = travelRequestRepository.save(travelRequest);
        return travelRequestMapper.toDTO(addedTravelRequest);
    }

    /**
     * Retrieves a travel request by ID
     * @param requestId The ID of the travel request to retrieve
     * @return The DTO representing the travel request details if found
     * @throws TravelRequestNotFoundException if the specified travel request is not found
     */
    @Override
    public TravelRequestDetailsDTO getTravelRequestById(int requestId) throws TravelRequestNotFoundException{
        TravelRequest travelRequest = travelRequestRepository.findById(requestId).orElseThrow(()->new TravelRequestNotFoundException(TRAVEL_REQUEST_NOT_FOUND_EXCEPTION_MESSAGE+requestId));

        if(travelBudgetAllocationRepository.existsByTravelRequest(travelRequest)){
            //if budget is allocated then it will fetch the info
            TravelBudgetAllocationDTO travelBudgetAllocationDTO = travelBudgetAllocationService.getBudgetAllocationsForTravelRequest(requestId);
            return travelRequestDetailsMapper.toDTO(travelRequest,travelBudgetAllocationDTO);
        }else {
            return travelRequestDetailsMapper.toDTO(travelRequest);
        }
    }

    /**
     * Retrieves all pending travel requests for the specified HR ID
     * @param hrId The ID of the HR to retrieve the pending requests for.
     * @return a list of pending travel requests
     * @throws HrIdNotFoundException if the associated HR ID is not found
     */
    @Override
    public List<TravelRequestDTO> getPendingTravelRequestsForHR(int hrId) throws HrIdNotFoundException{
        boolean hrIdExists = travelRequestRepository.existsByToBeApprovedByHRId(hrId);
        if(hrIdExists){
            List<TravelRequest> pendingRequest = travelRequestRepository.findByRequestStatusAndToBeApprovedByHRId(RequestStatus.NEW,hrId);
            return pendingRequest.stream()
                    .map(travelRequestMapper::toDTO)
                    .toList();
        }else {
            throw new HrIdNotFoundException("HR not found of Id: "+hrId);
        }
    }

    /**
     * Approves or rejects request based on the information given
     * @param requestId The ID of the request that would be approved or rejected
     * @param updateDTO DTO that will contain info whether the request is approved or rejected.
     * @throws InvalidHotelStarRatingException if Hotel assigned is not according to the role
     * @throws InvalidBudgetException if budget is not according to the grade of the employee
     * @throws InvalidGradeException if grade given is invalid
     * @throws TravelRequestNotFoundException if the travel request of the given ID is not found
     */
    @Override
    public void approveOrRejectRequest(int requestId, UpdateTravelRequestDTO updateDTO) throws InvalidHotelStarRatingException, InvalidBudgetException, InvalidGradeException, TravelRequestNotFoundException{
        if(updateDTO.getRequestStatus() == RequestStatus.APPROVED){
            approveRequest(requestId);
        } else{
            rejectRequest(requestId);
        }
    }


    /**
     * Method to approve the request
     * @param requestId The ID of the travel request that needs to be approved
     * @throws TravelRequestNotFoundException if travel request of the ID is not found
     */
    public void approveRequest(int requestId) throws TravelRequestNotFoundException{
        TravelRequest travelRequest = travelRequestRepository.findById(requestId).orElseThrow(()->new TravelRequestNotFoundException(TRAVEL_REQUEST_NOT_FOUND_EXCEPTION_MESSAGE+requestId));
        travelRequest.setRequestStatus(RequestStatus.APPROVED);
        travelRequest.setRequestApprovedOn(LocalDate.now());

        travelRequestRepository.save(travelRequest);
    }


    /**
     * Method to reject the travel request
     * @param requestId The ID of the travel request that needs to be rejected
     * @throws TravelRequestNotFoundException if the given ID of the travel request is not found
     */
    @Override
    public void rejectRequest(int requestId) throws TravelRequestNotFoundException{
        TravelRequest travelRequest = travelRequestRepository.findById(requestId).orElseThrow(()->new TravelRequestNotFoundException(TRAVEL_REQUEST_NOT_FOUND_EXCEPTION_MESSAGE+requestId));
        travelRequest.setRequestStatus(RequestStatus.REJECTED);
        travelRequestRepository.save(travelRequest);
    }

    /**
     * Helper method to validate the date given
     * @param fromDate the start date of the travel request
     * @param toDate the end date of the travel request
     * @throws InvalidDateException date is invalid if from date is lesser than present date or to date is lesser than from date
     */
    public void validateDate(LocalDate fromDate, LocalDate toDate) throws InvalidDateException{
        if(toDate.isBefore(fromDate) || toDate.equals(fromDate)){
            throw new InvalidDateException("End date must be greater than start date");
        } else if (fromDate.isBefore(LocalDate.now())) {
            throw new InvalidDateException("From date cannot be lesser than present date");
        }
    }

    /**
     * Helper method to validate priority according to the priority and total days given
     * @param fromDate The start date of the travel request
     * @param toDate The end date of the travel request
     * @param priority The priority of the travel request
     * @throws InvalidPriorityException throws if Priority and total days do not meet the constraints
     */
    public void validatePriority(LocalDate fromDate, LocalDate toDate, Priority priority) throws InvalidPriorityException{
        int totalDays = calculateTotalDays(fromDate, toDate);
        switch (priority){
            case PRIORITY_1:
                if(totalDays>30){
                    throw new InvalidPriorityException("Priority 1 requests cannot exceed 30 days");
                }
                break;

            case PRIORITY_2:
                if(totalDays>20){
                    throw new InvalidPriorityException("Priority 2 requests cannot exceed 20 days");
                }
                break;

            case PRIORITY_3:
                if(totalDays>10){
                    throw new InvalidPriorityException("Priority 3 requests cannot exceed 10 days");
                }
                break;

            default:
                throw new InvalidPriorityException("Invalid Priority");
        }
    }

    /**
     * Helper method to calculate the total days using start and end dates
     * @param fromDate Start date of the travel request
     * @param toDate End date of the travel request
     * @return total number of days
     */
    public int calculateTotalDays(LocalDate fromDate, LocalDate toDate) {
        return (int) ChronoUnit.DAYS.between(fromDate,toDate);
    }
}
