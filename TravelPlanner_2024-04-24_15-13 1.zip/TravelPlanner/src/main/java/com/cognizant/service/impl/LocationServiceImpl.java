package com.cognizant.service.impl;

import com.cognizant.dto.LocationDTO;
import com.cognizant.entities.Location;
import com.cognizant.repository.LocationRepository;
import com.cognizant.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Business Service implementing the LocationService interface for managing location
 */
@Service
public class LocationServiceImpl implements LocationService {
    private final LocationRepository locationRepository;

    /**
     * Constructs a new LocationServiceImpl with the specified dependencies
     * @param locationRepository The repository for accessing the location data
     */
    @Autowired
    public LocationServiceImpl(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    /**
     * Retrieves all locations and maps location entity to DTO
     * @return DTO list of all locations
     */
    @Override
    public List<LocationDTO> getAllLocationsDTO() {
        List<Location> locationList = locationRepository.findAll();
        List<LocationDTO> locationDTOList = new ArrayList<>();

        for (Location l : locationList){
            LocationDTO locationDTO = new LocationDTO();
            locationDTO.setLocationId(l.getId());
            locationDTO.setLocationName(l.getName());
            locationDTOList.add(locationDTO);
        }
        if(locationDTOList.isEmpty()){
            throw new NullPointerException("List is empty");
        }
        return locationDTOList;
    }
}
