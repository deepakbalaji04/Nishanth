package com.cognizant.service;
import com.cognizant.dto.LocationDTO;


import java.util.List;

/**
 * Service interface for managing interface
 */
public interface LocationService {
    /**
     * Retrieves all locations in the database
     * @return A list of all locations
     */
    public List<LocationDTO> getAllLocationsDTO();
}
