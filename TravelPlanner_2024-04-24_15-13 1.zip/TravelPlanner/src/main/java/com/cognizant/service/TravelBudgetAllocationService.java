package com.cognizant.service;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;

/**
 * Service interface for managing budget
 */
public interface TravelBudgetAllocationService {
    /**
     * Retrieves the budget associated with the given travel request
     * @param travelRequestId ID of the travel request whose budget we have to retrieve
     * @return The budget allocated to the travel request
     */
    TravelBudgetAllocationDTO getBudgetAllocationsForTravelRequest(int travelRequestId);

    /**
     * Assigning the budget to the given travel request
     * @param updateTravelRequestDTO the travel request that we want the budget to assign to
     */
    public void assignBudget(UpdateTravelRequestDTO updateTravelRequestDTO);

    /**
     * Calculates the budget using the start and end dates and budget per day
     * @param travelRequestDTO DTO providing the information of start, end dates and budget per day
     * @return The calculated budget
     */
    public int calculateBudget(TravelRequestDTO travelRequestDTO);
}
