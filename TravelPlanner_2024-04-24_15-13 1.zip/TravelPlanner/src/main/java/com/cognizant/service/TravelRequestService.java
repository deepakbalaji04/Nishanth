package com.cognizant.service;

import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;

import java.util.List;

/**
 * Service interface for managing travel request
 */
public interface TravelRequestService {
    /**
     * Adds a new travel request and obtains a travel request ID
     * @param travelRequestDTO DTO that carries information of the travel request
     * @return The ID of the new travel request
     */
    TravelRequestDTO addTravelRequest(TravelRequestDTO travelRequestDTO);

    /**
     * Retrieves a travel request by ID
     * @param requestId The ID of the travel request to retrieve
     * @return The DTO representing the travel request with the specified ID.
     */
    TravelRequestDetailsDTO getTravelRequestById(int requestId);

    /**
     * Retrieves all the new pending travel requests for the specified HR ID.
     * @param hrId The ID of the HR to retrieve the pending requests for.
     * @return List of all the pending travel requests
     */
    List<TravelRequestDTO> getPendingTravelRequestsForHR(int hrId);

    /**
     * Approve or reject request based on the provided information
     * @param requestId The ID of the request that would be approved or rejected
     * @param updateTravelRequestDTO DTO that will contain info whether the request is approved or rejected.
     */
    void approveOrRejectRequest(int requestId, UpdateTravelRequestDTO updateTravelRequestDTO);

    /**
     * Approves the request
     * @param requestId The ID of the travel request that needs to be approved
     */
    void approveRequest(int requestId);

    /**
     * Rejects the request
     * @param requestId The ID of the travel request that needs to be rejected
     */
    void rejectRequest(int requestId);
}
