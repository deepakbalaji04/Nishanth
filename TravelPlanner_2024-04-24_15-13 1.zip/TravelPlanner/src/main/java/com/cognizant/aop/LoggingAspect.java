package com.cognizant.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class);

    //return type, class-name.method(args)
    @Before("execution(* com.cognizant.*.*.*(..))")
    public void beforeAdvice(JoinPoint joinPoint){
        LOGGER.info("INFO: {}",joinPoint.getSignature().getName());
    }

    @After("execution(* com.cognizant.*.*.*(..))")
    public void afterAdvice(JoinPoint joinPoint){
        LOGGER.info("INFO: {}",joinPoint.getSignature().getName());
    }

    @AfterReturning(pointcut = "execution(* com.cognizant.*.*.*(..))",returning = "result")
    public void afterReturning(JoinPoint joinPoint, Object result){
        LOGGER.debug("DEBUG: {} Return Value: {}",joinPoint.getSignature().getName(),result);
    }

    @AfterThrowing(pointcut = "execution(* com.cognizant.*.*.*(..))",throwing = "error")
    public void afterThrowing(JoinPoint joinPoint, Throwable error){
        LOGGER.error("ERROR: {} threw exception: {}",joinPoint.getSignature().getName(),error.getMessage());
    }

}
