package com.cognizant.repository;

import com.cognizant.entities.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface to retrieve the locations stored in the database
 */
@Repository
public interface LocationRepository extends JpaRepository<Location, Integer> {
}
