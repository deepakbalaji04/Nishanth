package com.cognizant.repository;

import com.cognizant.entities.RequestStatus;
import com.cognizant.entities.TravelRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for managing travel request in the database
 */
@Repository
public interface TravelRequestRepository extends JpaRepository<TravelRequest,Integer> {
    /**
     * It checks whether the given HR ID exists in the database
     * @param hrId The ID of the HR to find the travel request for.
     * @return Returns true/false if HR ID exists/not exists.
     */
    boolean existsByToBeApprovedByHRId(int hrId);

    /**
     * Finds all the new travel requests associated with the given HR ID.
     * @param requestStatus The travel requests that are new  and not yet approved/rejected.
     * @param toBeApprovedByHRId The ID of the HR to find the travel request for.
     * @return A list of new  travel requests associated with the given HR ID.
     */
    List<TravelRequest> findByRequestStatusAndToBeApprovedByHRId(RequestStatus requestStatus, int toBeApprovedByHRId);

}
