package com.cognizant.repository;

import com.cognizant.entities.TravelBudgetAllocation;
import com.cognizant.entities.TravelRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface to manage budget allocation for the travel requests
 */
@Repository
public interface TravelBudgetAllocationRepository extends JpaRepository<TravelBudgetAllocation, Integer> {
    /**
     * Finds the budget that has been allocated to the given travel request
     * @param travelRequest The travel request whose budget needs to be retrieved
     * @return The travel budget associated with the given travel request
     */
    Optional<TravelBudgetAllocation> findByTravelRequest(TravelRequest travelRequest);

    /**
     * Checks if there is any budget allocated to the given budget
     * @param travelRequest The given travel request
     * @return true/false if the budget allocation exists/does not exist
     */
    boolean existsByTravelRequest(TravelRequest travelRequest);
}
