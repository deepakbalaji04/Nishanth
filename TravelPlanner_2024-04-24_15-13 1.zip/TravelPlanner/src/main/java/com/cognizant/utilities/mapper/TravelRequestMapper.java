package com.cognizant.utilities.mapper;

import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.entities.Location;
import com.cognizant.entities.TravelRequest;
import org.springframework.stereotype.Component;

@Component
public class TravelRequestMapper {
    public TravelRequestDTO toDTO(TravelRequest travelRequest){
        TravelRequestDTO travelRequestDTO = new TravelRequestDTO();
        travelRequestDTO.setRequestId(travelRequest.getRequestId());
        travelRequestDTO.setRaisedByEmployeeId(travelRequest.getRaisedByEmployeeId());
        travelRequestDTO.setToBeApprovedByHRId(travelRequest.getToBeApprovedByHRId());
        travelRequestDTO.setRequestRaisedOn(travelRequest.getRequestRaisedOn());
        travelRequestDTO.setFromDate(travelRequest.getFromDate());
        travelRequestDTO.setToDate(travelRequest.getToDate());
        travelRequestDTO.setPurposeOfTravel(travelRequest.getPurposeOfTravel());
        travelRequestDTO.setLocationId(travelRequest.getLocation().getId());
        travelRequestDTO.setRequestStatus(travelRequest.getRequestStatus());
        travelRequestDTO.setRequestApprovedOn(travelRequest.getRequestApprovedOn());
        travelRequestDTO.setPriority(travelRequest.getPriority());

        return travelRequestDTO;
    }

    public TravelRequest toEntity(TravelRequestDTO travelRequestDTO){
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(travelRequestDTO.getRaisedByEmployeeId());
        travelRequest.setToBeApprovedByHRId(travelRequestDTO.getToBeApprovedByHRId());
        travelRequest.setFromDate(travelRequestDTO.getFromDate());
        travelRequest.setToDate(travelRequestDTO.getToDate());
        travelRequest.setPurposeOfTravel(travelRequestDTO.getPurposeOfTravel());

        Location location = new Location();
        location.setId(travelRequestDTO.getLocationId());
        travelRequest.setLocation(location);
        travelRequest.setPriority(travelRequestDTO.getPriority());

        return travelRequest;
    }
}
