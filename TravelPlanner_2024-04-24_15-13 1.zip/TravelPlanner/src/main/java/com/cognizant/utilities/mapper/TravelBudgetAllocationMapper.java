package com.cognizant.utilities.mapper;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.entities.TravelBudgetAllocation;
import org.springframework.stereotype.Component;

@Component
public class TravelBudgetAllocationMapper {
    public TravelBudgetAllocationDTO toDTO(TravelBudgetAllocation travelBudgetAllocation){

        TravelBudgetAllocationDTO travelBudgetAllocationDTO = new TravelBudgetAllocationDTO();
        travelBudgetAllocationDTO.setTravelBudgetAllocationId(travelBudgetAllocation.getId());
        travelBudgetAllocationDTO.setTravelRequestId(travelBudgetAllocation.getTravelRequest().getRequestId());
        travelBudgetAllocationDTO.setApprovedBudget(travelBudgetAllocation.getApprovedBudget());
        travelBudgetAllocationDTO.setApprovedModeOfTravel(travelBudgetAllocation.getApprovedModeOfTravel());
        travelBudgetAllocationDTO.setApprovedHotelStarRating(travelBudgetAllocation.getApprovedHotelStarRating());

        return travelBudgetAllocationDTO;
    }
}
