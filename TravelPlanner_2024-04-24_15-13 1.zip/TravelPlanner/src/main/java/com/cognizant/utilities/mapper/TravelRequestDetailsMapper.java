package com.cognizant.utilities.mapper;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.entities.TravelRequest;
import org.springframework.stereotype.Component;

@Component
public class TravelRequestDetailsMapper {
    public TravelRequestDetailsDTO toDTO(TravelRequest travelRequest){
        TravelRequestDetailsDTO travelRequestDetailsDTO = new TravelRequestDetailsDTO();
        travelRequestDetailsDTO.setRequestId(travelRequest.getRequestId());
        travelRequestDetailsDTO.setRaisedByEmployeeId(travelRequest.getRaisedByEmployeeId());
        travelRequestDetailsDTO.setToBeApprovedByHRId(travelRequest.getToBeApprovedByHRId());
        travelRequestDetailsDTO.setRequestRaisedOn(travelRequest.getRequestRaisedOn());
        travelRequestDetailsDTO.setFromDate(travelRequest.getFromDate());
        travelRequestDetailsDTO.setToDate(travelRequest.getToDate());
        travelRequestDetailsDTO.setPurposeOfTravel(travelRequest.getPurposeOfTravel());
        travelRequestDetailsDTO.setLocationId(travelRequest.getLocation().getId());
        travelRequestDetailsDTO.setRequestStatus(travelRequest.getRequestStatus());
        travelRequestDetailsDTO.setRequestApprovedOn(travelRequest.getRequestApprovedOn());
        travelRequestDetailsDTO.setPriority(travelRequest.getPriority());

        return travelRequestDetailsDTO;
    }

    public TravelRequestDetailsDTO toDTO(TravelRequest travelRequest, TravelBudgetAllocationDTO travelBudgetAllocationDTO){
        TravelRequestDetailsDTO travelRequestDetailsDTO = new TravelRequestDetailsDTO();
        travelRequestDetailsDTO.setRequestId(travelRequest.getRequestId());
        travelRequestDetailsDTO.setRaisedByEmployeeId(travelRequest.getRaisedByEmployeeId());
        travelRequestDetailsDTO.setToBeApprovedByHRId(travelRequest.getToBeApprovedByHRId());
        travelRequestDetailsDTO.setRequestRaisedOn(travelRequest.getRequestRaisedOn());
        travelRequestDetailsDTO.setFromDate(travelRequest.getFromDate());
        travelRequestDetailsDTO.setToDate(travelRequest.getToDate());
        travelRequestDetailsDTO.setPurposeOfTravel(travelRequest.getPurposeOfTravel());
        travelRequestDetailsDTO.setLocationId(travelRequest.getLocation().getId());
        travelRequestDetailsDTO.setRequestStatus(travelRequest.getRequestStatus());
        travelRequestDetailsDTO.setRequestApprovedOn(travelRequest.getRequestApprovedOn());
        travelRequestDetailsDTO.setPriority(travelRequest.getPriority());

        travelRequestDetailsDTO.setApprovedBudget(travelBudgetAllocationDTO.getApprovedBudget());
        travelRequestDetailsDTO.setApprovedModeOfTravel(travelBudgetAllocationDTO.getApprovedModeOfTravel());
        travelRequestDetailsDTO.setApprovedHotelStarRating(travelBudgetAllocationDTO.getApprovedHotelStarRating());

        return travelRequestDetailsDTO;
    }
}
