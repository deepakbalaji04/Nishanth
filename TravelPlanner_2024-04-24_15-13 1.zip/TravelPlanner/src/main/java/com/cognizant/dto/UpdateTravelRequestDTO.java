package com.cognizant.dto;

import com.cognizant.entities.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateTravelRequestDTO {
    private int requestId;
    private RequestStatus requestStatus;
    private int budgetPerDay;
    private int approvedBudget;
    private ModeOfTravel approvedModeOfTravel;
    private HotelStarRating approvedHotelStarRating;
    private Grade grade;
    private Role role;
}
