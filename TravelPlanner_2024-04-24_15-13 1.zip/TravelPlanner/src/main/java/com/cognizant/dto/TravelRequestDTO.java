package com.cognizant.dto;

import com.cognizant.entities.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TravelRequestDTO {

    private int requestId;

    @NotNull(message = "Raised by employee ID is required")
    @Positive(message = "Employee Id must be positive")
    private int raisedByEmployeeId;

    @NotNull(message = "To be approved by HR ID is required")
    @Positive(message = "HR Id must be positive")
    private int toBeApprovedByHRId;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate requestRaisedOn;

    @NotNull(message = "From Date is required")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate fromDate;

    @NotNull(message = "To Date is required")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate toDate;

    @NotBlank(message = "Purpose of travel is required")
    @Size(max = 100, message = "Purpose of travel cannot exceed 100 characters")
    private String purposeOfTravel;

    @NotNull(message = "Location ID is required")
    private int locationId;

    private RequestStatus requestStatus;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate requestApprovedOn;

    private Priority priority;

    private int budgetPerDay;

}
