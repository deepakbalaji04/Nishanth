package com.cognizant.dto;

import com.cognizant.entities.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TravelRequestDetailsDTO {
    private int requestId;
    private int raisedByEmployeeId;
    private int toBeApprovedByHRId;
    private LocalDate requestRaisedOn;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate fromDate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate toDate;
    private String purposeOfTravel;
    private int locationId;
    private RequestStatus requestStatus;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate requestApprovedOn;
    private Priority priority;
    private int approvedBudget;
    private ModeOfTravel approvedModeOfTravel;
    private HotelStarRating approvedHotelStarRating;

}
