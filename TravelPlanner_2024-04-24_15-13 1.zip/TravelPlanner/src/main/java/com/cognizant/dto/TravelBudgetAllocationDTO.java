package com.cognizant.dto;

import com.cognizant.entities.HotelStarRating;
import com.cognizant.entities.ModeOfTravel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TravelBudgetAllocationDTO {

    private int travelBudgetAllocationId;
    private int travelRequestId;
    private int approvedBudget;
    private ModeOfTravel approvedModeOfTravel;
    private HotelStarRating approvedHotelStarRating;
}
