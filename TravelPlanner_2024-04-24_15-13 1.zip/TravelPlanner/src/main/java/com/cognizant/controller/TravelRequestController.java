package com.cognizant.controller;

import com.cognizant.dto.LocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.exception.*;
import com.cognizant.service.impl.LocationServiceImpl;
import com.cognizant.service.impl.TravelBudgetAllocationServiceImpl;
import com.cognizant.service.impl.TravelRequestServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/travelrequests")
@CrossOrigin("http://localhost:4200/")
@Tag(name="TravelPlanner", description="TravelPlanner Rest API")
public class TravelRequestController {
    private final TravelRequestServiceImpl travelRequestService;
    private final TravelBudgetAllocationServiceImpl travelBudgetAllocationService;
    private final LocationServiceImpl locationService;

    public TravelRequestController(TravelRequestServiceImpl travelRequestService, TravelBudgetAllocationServiceImpl travelBudgetAllocationService, LocationServiceImpl locationService) {
        this.travelRequestService = travelRequestService;
        this.travelBudgetAllocationService = travelBudgetAllocationService;
        this.locationService = locationService;
    }

    @Operation(description = "Retrieve all the locations")
    @GetMapping("/locations")
    public ResponseEntity<List<LocationDTO>>getAllLocations(){
        List<LocationDTO> locationDTO = locationService.getAllLocationsDTO();
        return new ResponseEntity<>(locationDTO,HttpStatus.OK);     //200
    }

    @Operation(description = "Create a new travel request")
    @PostMapping("/new")
    public ResponseEntity<Object>addTravelRequest(@RequestBody @Valid TravelRequestDTO travelRequestDTO){
        try {
            TravelRequestDTO travelRequest = travelRequestService.addTravelRequest(travelRequestDTO);
            return new ResponseEntity<>(travelRequest, HttpStatus.CREATED);     //201
        } catch (InvalidDateException | InvalidPriorityException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.UNPROCESSABLE_ENTITY);    //422
        }
    }

    @Operation(description = "Retrieve the travel request detail by providing the request Id")
    @GetMapping("/{travelRequestId}")
    public ResponseEntity<Object>getTravelRequestById(@PathVariable("travelRequestId") int travelRequestId){
        try {
            TravelRequestDetailsDTO travelRequestDetailsDTO = travelRequestService.getTravelRequestById(travelRequestId);
            return new ResponseEntity<>(travelRequestDetailsDTO, HttpStatus.OK);    //200
        } catch (TravelRequestNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);   //404
        }
    }

    @Operation(description = "Retrieve the list of all the new requests assigned to the HR")
    @GetMapping("/{hrId}/pending")
    public ResponseEntity<Object>getPendingTravelRequestsForHR(@PathVariable("hrId")int hrId){
        try {
            List<TravelRequestDTO>pendingRequests = travelRequestService.getPendingTravelRequestsForHR(hrId);
            return new ResponseEntity<>(pendingRequests, HttpStatus.OK);    //200
        } catch (HrIdNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);   //404
        }
    }

    @Operation(description = "Update the request status to approved or rejected")
    @PutMapping("/{travelRequestId}/update")
    public ResponseEntity<Object> approveRequestOrRejectRequest(@PathVariable("travelRequestId")int travelRequestId, @RequestBody @Valid UpdateTravelRequestDTO updateTravelRequestDTO){
        try {
            travelRequestService.approveOrRejectRequest(travelRequestId, updateTravelRequestDTO);
            return new ResponseEntity<>(HttpStatus.OK);     //200
        } catch (InvalidHotelStarRatingException | InvalidBudgetException | InvalidGradeException | TravelRequestNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.UNPROCESSABLE_ENTITY);    //422
        }
    }

    @Operation(description = "Calculate the budget")
    @PostMapping("/calculatebudget")
    public ResponseEntity<Object> calculateBudget(@RequestBody TravelRequestDTO travelRequestDTO){
        int budget = travelBudgetAllocationService.calculateBudget(travelRequestDTO);
        return new ResponseEntity<>(budget,HttpStatus.OK);      //200
    }

    @Operation(description = "Assigning the budget to the particular budget")
    @PostMapping("/assignbudget")
    public ResponseEntity<Object>assignBudget(@RequestBody UpdateTravelRequestDTO updateTravelRequestDTO){
        try {
            travelBudgetAllocationService.assignBudget(updateTravelRequestDTO);
            return new ResponseEntity<>(HttpStatus.CREATED);       //201
        } catch (InvalidHotelStarRatingException | InvalidBudgetException | InvalidGradeException | BudgetAlreadyExistsException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.UNPROCESSABLE_ENTITY);    //422
        }
    }

}
