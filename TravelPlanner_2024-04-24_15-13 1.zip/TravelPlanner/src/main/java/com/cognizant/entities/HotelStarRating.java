package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the types of Hotel Star Rating
 */
@Getter
public enum HotelStarRating {
    STAR_3("STAR_3"),
    STAR_5("STAR_5"),
    STAR_7("STAR_7");

    private final String value;
    HotelStarRating(String rating) {
        this.value = rating;
    }
}
