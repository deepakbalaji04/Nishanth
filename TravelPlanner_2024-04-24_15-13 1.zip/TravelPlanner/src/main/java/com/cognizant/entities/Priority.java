package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the types of priority
 */
@Getter
public enum Priority {

    PRIORITY_1("PRIORITY_1"),
    PRIORITY_2("PRIORITY_2"),
    PRIORITY_3("PRIORITY_3"),
    INVALID("INVALID");

    private final String value;

    Priority(String priority) {
        this.value = priority;
    }
}
