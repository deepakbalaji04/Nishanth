package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the grade types
 */
@Getter
public enum Grade {
    GRADE_1("GRADE_1"), 
    GRADE_2("GRADE_2"), 
    GRADE_3("GRADE_3"), 
    INVALID("INVALID");

    private final String value;

    Grade(String grade) {
        this.value = grade;
    }
}
