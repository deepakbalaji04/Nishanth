package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the types of request status
 */
@Getter
public enum RequestStatus {
    NEW("NEW"),
    APPROVED("APPROVED"),
    REJECTED("REJECTED");

    private final String value;

    RequestStatus(String requestStatus){
        this.value = requestStatus;
    }
}
