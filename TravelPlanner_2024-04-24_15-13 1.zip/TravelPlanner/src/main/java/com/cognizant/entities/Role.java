package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the types of roles
 */
@Getter
public enum Role {
    EMPLOYEE("EMPLOYEE"),
    HR("HR"),
    TRAVEL_DESK_EXE("TRAVEL_DESK_EXE");
    private final String value;

    Role(String role) {
        this.value = role;
    }
}
