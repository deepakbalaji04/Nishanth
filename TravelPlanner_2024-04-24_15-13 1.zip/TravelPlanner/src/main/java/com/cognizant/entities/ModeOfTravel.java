package com.cognizant.entities;

import lombok.Getter;

/**
 * Enum for representing the types of Mode of Travel
 */
@Getter
public enum ModeOfTravel {
    AIR("AIR"),
    TRAIN("TRAIN"),
    BUS("BUS");

    private final String value;
    ModeOfTravel(String modeOfTravel) {
        this.value = modeOfTravel;
    }
}
