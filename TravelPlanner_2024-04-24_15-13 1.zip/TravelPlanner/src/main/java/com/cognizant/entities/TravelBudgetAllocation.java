package com.cognizant.entities;

import jakarta.persistence.*;
import lombok.*;

/**
 * Represents the Budget that would be allocated to the travel request if approved
 */
@Builder
@Data                   // automatically generates getters and setters
@AllArgsConstructor     //generates constructor for all fields in class
@NoArgsConstructor      //generates no-arg constructor
@Entity                 //instance of this class will be stored in the database
@Table(name = "TravelBudgetAllocations")
public class TravelBudgetAllocation {
    /** The unique identifier of the budget allocation */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Pk_Travel_Budget_Allocations_Id")
    private int id;

    /**
     * The ID of the travel request that this budget is allocated
     * It has one-to-one relationship between TravelRequest and TravelBudgetAllocation
     */
    @OneToOne
    @JoinColumn(name = "Fk_Travel_Request_Id")
    private TravelRequest travelRequest;

    /** The budget that would be assigned to the travel request */
    @Column(name = "Approved_Budget")
    private int approvedBudget;

    /** The mode of travel that the HR will allocate (Air,Train,Bus) */
    @Enumerated(EnumType.STRING)
    @Column(name = "Approved_Mode_Of_Travel")
    private ModeOfTravel approvedModeOfTravel;

    /** The star rating of the hotel that the HR will allocate (3,5,7) */
    @Enumerated(EnumType.STRING)
    @Column(name = "Approved_Hotel_Star_Rating")
    private HotelStarRating approvedHotelStarRating;

}
