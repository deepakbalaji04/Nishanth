package com.cognizant.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * Represents a travel request made by the employee
 */
@Builder
@Data                   // automatically generates getters and setters
@AllArgsConstructor     //generates constructor for all fields in class
@NoArgsConstructor      //generates no-arg constructor
@Entity                 //instance of this class will be stored in the database
@Table(name = "TravelRequests")
public class TravelRequest {
    /** The unique identifier of the travel request */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Pk_Request_Id")
    private int requestId;

    /** The ID of the employee who will raise the request */
    @Column(name="Raised_By_Employee_Id")
    private int raisedByEmployeeId;

    /** The ID of the HR who needs to approve the request */
    @Column(name = "To_Be_Approved_By_HR_Id")
    private int toBeApprovedByHRId;

    /** The date when the travel request was raised */
    @Column(name = "Request_Raised_On")
    private LocalDate requestRaisedOn;

    /** The start date of the travel */
    @Column(name = "From_Date")
    private LocalDate fromDate;

    /** The end date of the travel */
    @Column(name = "To_Date")
    private LocalDate toDate;

    /** The purpose of the travel */
    @Column(name = "Purpose_Of_Travel", length = 100)
    private String purposeOfTravel;

    /**
     * The Location ID of the travel
     * It is many-to-one relationship between TravelRequest and Location
     */
    @ManyToOne
    @JoinColumn(name = "Fk_Location_Id")
    private Location location;

    /** The status of the travel request (NEW, APPROVED, REJECTED) */
    @Enumerated(EnumType.STRING)        //instructs JPA to persist enum values as String
    @Column(name = "Request_Status")
    private RequestStatus requestStatus;

    /** The date when the travel request was approved */
    @Column(name = "Request_Approved_On")
    private LocalDate requestApprovedOn;

    /** The priority of the travel request (1,2,3) */
    @Enumerated(EnumType.STRING)
    @Column(name = "Priority")
    private Priority priority;


}
