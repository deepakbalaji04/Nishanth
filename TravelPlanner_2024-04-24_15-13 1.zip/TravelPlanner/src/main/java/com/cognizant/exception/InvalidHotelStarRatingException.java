package com.cognizant.exception;

public class InvalidHotelStarRatingException extends RuntimeException{
    public InvalidHotelStarRatingException(String message) {
        super(message);
    }
}
