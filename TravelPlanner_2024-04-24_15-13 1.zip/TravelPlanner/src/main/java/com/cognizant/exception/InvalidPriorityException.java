package com.cognizant.exception;

public class InvalidPriorityException extends RuntimeException {
    public InvalidPriorityException(String message) {
        super(message);
    }
}
