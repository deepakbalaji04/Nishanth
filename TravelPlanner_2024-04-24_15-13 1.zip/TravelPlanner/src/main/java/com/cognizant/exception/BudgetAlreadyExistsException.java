package com.cognizant.exception;

public class BudgetAlreadyExistsException extends RuntimeException{
    public BudgetAlreadyExistsException(String message){
        super(message);
    }
}
