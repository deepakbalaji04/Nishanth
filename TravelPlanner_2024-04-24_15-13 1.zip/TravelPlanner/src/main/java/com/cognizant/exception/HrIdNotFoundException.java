package com.cognizant.exception;

public class HrIdNotFoundException extends RuntimeException{
    public HrIdNotFoundException(String message) {
        super(message);
    }
}
