package com.cognizant.service.impl;

import com.cognizant.dto.LocationDTO;
import com.cognizant.entities.Location;
import com.cognizant.repository.LocationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;


class LocationServiceImplTest {
    @Mock
    private LocationRepository locationRepository;
    @InjectMocks
    private LocationServiceImpl locationServiceImpl;

    @BeforeEach
    void setUp() throws Exception{
        MockitoAnnotations.openMocks(this);    }

    // JUnit test for getAllLocationsDTO method
    @Test
    void getAllLocationsDTO_positive(){
        List<Location> expectedLocationList = List.of(new Location(1, "Location 1"), new Location(2,"Location 2"));
        when(locationRepository.findAll()).thenReturn(expectedLocationList);
        List<LocationDTO> locationDTOList = locationServiceImpl.getAllLocationsDTO();
        assertNotNull(locationDTOList);
        assertEquals(locationDTOList.size(), expectedLocationList.size());
    }

    @Test
    void getAllLocationsDTO_exception(){
        when(locationRepository.findAll()).thenReturn(Collections.emptyList());
        assertThrows(NullPointerException.class, ()-> locationServiceImpl.getAllLocationsDTO());
    }
}