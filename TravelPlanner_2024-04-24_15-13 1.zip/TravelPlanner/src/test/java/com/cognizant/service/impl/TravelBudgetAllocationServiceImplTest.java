package com.cognizant.service.impl;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.entities.*;
import com.cognizant.exception.BudgetAlreadyExistsException;
import com.cognizant.exception.InvalidBudgetException;
import com.cognizant.exception.InvalidGradeException;
import com.cognizant.exception.InvalidHotelStarRatingException;
import com.cognizant.repository.TravelBudgetAllocationRepository;
import com.cognizant.utilities.mapper.TravelBudgetAllocationMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.InvalidDataAccessApiUsageException;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class TravelBudgetAllocationServiceImplTest {
    @Mock
    private TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Mock
    private TravelBudgetAllocationMapper travelBudgetAllocationMapper;
    @InjectMocks
    private  TravelBudgetAllocationServiceImpl travelBudgetAllocationService;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    //TESTING GET_BUDGET_ALLOCATIONS_FOR_TRAVEL_REQUEST
    @Test
    void getBudgetAllocationsForTravelRequestPositive() {
        try{
            int allocationId = 1;
            int requestId = 5;
            int budget = 100000;
            ModeOfTravel mode = ModeOfTravel.AIR;
            HotelStarRating star = HotelStarRating.STAR_5;

            TravelRequest travelRequest = new TravelRequest();
            travelRequest.setRequestId(requestId);

            TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
            travelBudgetAllocation.setId(allocationId);
            travelBudgetAllocation.setTravelRequest(travelRequest);
            travelBudgetAllocation.setApprovedBudget(budget);
            travelBudgetAllocation.setApprovedModeOfTravel(mode);
            travelBudgetAllocation.setApprovedHotelStarRating(star);

            //Expected
            TravelBudgetAllocationDTO expectedDTO = new TravelBudgetAllocationDTO();
            expectedDTO.setTravelBudgetAllocationId(allocationId);
            expectedDTO.setTravelRequestId(travelRequest.getRequestId());
            expectedDTO.setApprovedBudget(budget);
            expectedDTO.setApprovedModeOfTravel(mode);
            expectedDTO.setApprovedHotelStarRating(star);

            when(travelBudgetAllocationRepository.findByTravelRequest(travelRequest)).thenReturn(Optional.of(travelBudgetAllocation));
            when(travelBudgetAllocationMapper.toDTO(travelBudgetAllocation)).thenReturn(expectedDTO);

            TravelBudgetAllocationDTO result = travelBudgetAllocationService.getBudgetAllocationsForTravelRequest(requestId);
            assertEquals(expectedDTO, result);

        }catch (Exception e){
            fail();
        }
    }

    @Test
    void getBudgetAllocationsForTravelRequestNegative(){
        int requestId = 5;

        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRequestId(requestId);

        when(travelBudgetAllocationRepository.findByTravelRequest(travelRequest)).thenReturn(Optional.empty());

        assertThrows(InvalidDataAccessApiUsageException.class,()->travelBudgetAllocationService.getBudgetAllocationsForTravelRequest(requestId));
    }

    //TESTING OF ASSIGN_BUDGET
    @Test
    void testAssignBudgetPositive(){
        try {
            int requestId = 1;
            int approvedBudget = 10000;
            ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
            Grade grade = Grade.GRADE_1;
            Role role = Role.HR;
            ArgumentCaptor<TravelBudgetAllocation>captor = ArgumentCaptor.forClass(TravelBudgetAllocation.class);
            //Will be passed to the method
            UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                    .requestId(requestId)
                    .approvedBudget(approvedBudget)
                    .approvedModeOfTravel(modeOfTravel)
                    .approvedHotelStarRating(hotelStarRating)
                    .grade(grade)
                    .role(role)
                    .build();

            TravelRequest travelRequest = TravelRequest.builder()
                    .requestId(requestId)
                    .build();
            TravelBudgetAllocation captureTravelBudgetAllocation = TravelBudgetAllocation.builder()
                    .travelRequest(travelRequest)
                    .approvedBudget(approvedBudget)
                    .approvedModeOfTravel(modeOfTravel)
                    .approvedHotelStarRating(hotelStarRating)
                    .build();

            travelBudgetAllocationService.assignBudget(updateTravelRequestDTO);
            verify(travelBudgetAllocationRepository).save(captor.capture());
            assertEquals(captureTravelBudgetAllocation,captor.getValue());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testAssignBudgetNegative_BudgetExists(){
        int requestId = 1;
        int approvedBudget = 10000;
        ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_3;
        Grade grade = Grade.GRADE_1;
        Role role = Role.HR;

        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(requestId)
                .approvedBudget(approvedBudget)
                .approvedModeOfTravel(modeOfTravel)
                .approvedHotelStarRating(hotelStarRating)
                .grade(grade)
                .role(role)
                .build();
        TravelRequest travelRequest = TravelRequest.builder()
                .requestId(requestId)
                .build();

        TravelBudgetAllocation travelBudgetAllocation = TravelBudgetAllocation.builder().id(1).build();

        when(travelBudgetAllocationRepository.findByTravelRequest(travelRequest)).thenReturn(Optional.of(travelBudgetAllocation));

        assertThrows(BudgetAlreadyExistsException.class,()->travelBudgetAllocationService.assignBudget(updateTravelRequestDTO));
    }

    @Test
    void testAssignBudgetNegative_InvalidHotel(){
        int requestId = 1;
        int approvedBudget = 10000;
        ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_3;
        Grade grade = Grade.GRADE_1;
        Role role = Role.HR;

        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(requestId)
                .approvedBudget(approvedBudget)
                .approvedModeOfTravel(modeOfTravel)
                .approvedHotelStarRating(hotelStarRating)
                .grade(grade)
                .role(role)
                .build();
        assertThrows(InvalidHotelStarRatingException.class,()->travelBudgetAllocationService.assignBudget(updateTravelRequestDTO));
    }

    @Test
    void testAssignBudgetNegative_InvalidBudget(){
        int requestId = 1;
        int approvedBudget = 110000;
        int budgetPerDay = 11000;
        ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
        Grade grade = Grade.GRADE_1;
        Role role = Role.HR;

        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(requestId)
                .budgetPerDay(budgetPerDay)
                .approvedBudget(approvedBudget)
                .approvedModeOfTravel(modeOfTravel)
                .approvedHotelStarRating(hotelStarRating)
                .grade(grade)
                .role(role)
                .build();
        assertThrows(InvalidBudgetException.class,()->travelBudgetAllocationService.assignBudget(updateTravelRequestDTO));
    }

    @Test
    void testAssignBudgetNegative_InvalidGrade(){
        int requestId = 1;
        int approvedBudget = 100000;
        int budgetPerDay = 10000;
        ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
        Grade grade = Grade.INVALID;
        Role role = Role.HR;

        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(requestId)
                .budgetPerDay(budgetPerDay)
                .approvedBudget(approvedBudget)
                .approvedModeOfTravel(modeOfTravel)
                .approvedHotelStarRating(hotelStarRating)
                .grade(grade)
                .role(role)
                .build();
        assertThrows(InvalidGradeException.class,()->travelBudgetAllocationService.assignBudget(updateTravelRequestDTO));
    }

    //TESTING OF CALCULATE_BUDGET
    @Test
    void calculateBudgetPositive_WhenBudgetPerDayIsPositive(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(10);
            int budgetPerDay = 1000;
            int expectedBudget = 10000;
            TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                    .fromDate(fromDate)
                    .toDate(toDate)
                    .budgetPerDay(budgetPerDay)
                    .build();
            assertEquals(expectedBudget, travelBudgetAllocationService.calculateBudget(travelRequestDTO));
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void calculateBudgetPositive_WhenBudgetPerDayIsNegative(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(10);
            int budgetPerDay = -1000;
            int expectedBudget = 10000;
            TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                    .fromDate(fromDate)
                    .toDate(toDate)
                    .budgetPerDay(budgetPerDay)
                    .build();
            assertEquals(expectedBudget, travelBudgetAllocationService.calculateBudget(travelRequestDTO));
        }catch (Exception e){
            fail();
        }
    }

    //TESTING OF VALIDATE_HOTEL_STAR_RATING
    @Test
    void validateHotelStarRatingPositive_Hr_Star5(){
        try{
            Role role = Role.HR;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingPositive_Hr_Star7(){
        try{
            Role role = Role.HR;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_7;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingNegative_Hr_Star3(){
        Role role = Role.HR;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_3;
        assertThrows(InvalidHotelStarRatingException.class, ()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));
    }

    @Test
    void validateHotelStarRatingPositive_Employee_Star3(){
        try{
            Role role = Role.EMPLOYEE;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_3;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingPositive_Employee_Star5(){
        try{
            Role role = Role.EMPLOYEE;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingNegative_Employee_Star7(){
        Role role = Role.EMPLOYEE;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_7;
        assertThrows(InvalidHotelStarRatingException.class, ()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));
    }

    @Test
    void validateHotelStarRatingPositive_TravelExec_Star3(){
        try{
            Role role = Role.TRAVEL_DESK_EXE;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_3;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingPositive_TravelExec_Star5(){
        try{
            Role role = Role.TRAVEL_DESK_EXE;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));

        } catch (Exception e){
            fail();
        }
    }

    @Test
    void validateHotelStarRatingNegative_TravelExec_Star7(){
        Role role = Role.TRAVEL_DESK_EXE;
        HotelStarRating hotelStarRating = HotelStarRating.STAR_7;
        assertThrows(InvalidHotelStarRatingException.class, ()->travelBudgetAllocationService.validateHotelStarRating(role, hotelStarRating));
    }

    //TESTING OF VALIDATE BUDGET
    @Test
    void validateBudgetPositive_Grade1(){
        try {
            int budgetPerDay = 9000;
            Grade grade = Grade.GRADE_1;
            travelBudgetAllocationService.validateBudget(budgetPerDay,grade);
            assertDoesNotThrow(()->travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void validateBudgetNegative_Grade1(){
        int budgetPerDay = 10001;
        Grade grade = Grade.GRADE_1;
        assertThrows(InvalidBudgetException.class,()-> travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
    }

    @Test
    void validateBudgetPositive_Grade2(){
        try {
            int budgetPerDay = 11000;
            Grade grade = Grade.GRADE_2;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void validateBudgetNegative_Grade2(){
        int budgetPerDay = 12501;
        Grade grade = Grade.GRADE_2;
        assertThrows(InvalidBudgetException.class,()-> travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
    }

    @Test
    void validateBudgetPositive_Grade3(){
        try {
            int budgetPerDay = 15000;
            Grade grade = Grade.GRADE_3;
            assertDoesNotThrow(()->travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void validateBudgetNegative_Grade3(){
        int budgetPerDay = 15001;
        Grade grade = Grade.GRADE_3;
        assertThrows(InvalidBudgetException.class,()-> travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
    }

    @Test
    void validateBudgetNegative_InvalidGrade(){
        int budgetPerDay = 15001;
        Grade grade = Grade.INVALID;
        assertThrows(InvalidGradeException.class,()-> travelBudgetAllocationService.validateBudget(budgetPerDay,grade));
    }
}