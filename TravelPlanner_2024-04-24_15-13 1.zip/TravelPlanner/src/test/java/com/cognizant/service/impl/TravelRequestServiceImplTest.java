package com.cognizant.service.impl;

import com.cognizant.dto.TravelBudgetAllocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.entities.*;
import com.cognizant.exception.*;
import com.cognizant.repository.TravelBudgetAllocationRepository;
import com.cognizant.repository.TravelRequestRepository;
import com.cognizant.utilities.mapper.TravelRequestDetailsMapper;
import com.cognizant.utilities.mapper.TravelRequestMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class TravelRequestServiceImplTest {
    @Mock
    private TravelRequestRepository travelRequestRepository;
    @Mock
    private TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Mock
    private TravelRequestMapper travelRequestMapper;
    @Mock
    private TravelRequestDetailsMapper travelRequestDetailsMapper;
    @Mock
    private TravelBudgetAllocationServiceImpl travelBudgetAllocationService;
    @Spy    //partial mock of a real object
    @InjectMocks
    private TravelRequestServiceImpl travelRequestService;
    @BeforeEach
    void setUp() throws Exception{
        MockitoAnnotations.openMocks(this);
    }

    //TESTING ADD_TRAVEL_REQUEST
    @Test
    void testAddTravelRequestPositive() {
        try{
            int employeeId = 1;
            LocalDate presentDate = LocalDate.now();
            LocalDate fromDate = presentDate.plusDays(2);
            LocalDate toDate = fromDate.plusDays(30);

            //DTO that will be given as an input
            TravelRequestDTO travelRequestDTO = new TravelRequestDTO();
            travelRequestDTO.setRaisedByEmployeeId(employeeId);
            travelRequestDTO.setFromDate(fromDate);
            travelRequestDTO.setToDate(toDate);
            travelRequestDTO.setLocationId(1);
            travelRequestDTO.setPriority(Priority.valueOf("PRIORITY_1"));

            //Expected entity from mapper
            TravelRequest expectedEntity = new TravelRequest();
            expectedEntity.setRaisedByEmployeeId(employeeId);
            expectedEntity.setFromDate(fromDate);
            expectedEntity.setToDate(toDate);
            expectedEntity.setLocation(new Location(1,"Location1"));
            expectedEntity.setPriority(Priority.valueOf("PRIORITY_1"));

            //Travel Request Entity returned by repository
            TravelRequest addedEntity = new TravelRequest();
            addedEntity.setRaisedByEmployeeId(employeeId);
            addedEntity.setFromDate(fromDate);
            addedEntity.setToDate(toDate);
            addedEntity.setRequestStatus(RequestStatus.valueOf("NEW"));
            addedEntity.setRequestRaisedOn(presentDate);
            addedEntity.setLocation(new Location(1,"Location1"));
            addedEntity.setPriority(Priority.valueOf("PRIORITY_1"));

            //Travel Request DTO returned by mapper
            TravelRequestDTO expectedDTO = new TravelRequestDTO();
            expectedDTO.setRaisedByEmployeeId(employeeId);
            expectedDTO.setFromDate(fromDate);
            expectedDTO.setToDate(toDate);
            expectedDTO.setLocationId(1);
            expectedDTO.setRequestRaisedOn(presentDate);
            expectedDTO.setRequestStatus(RequestStatus.valueOf("NEW"));

            when(travelRequestMapper.toEntity(travelRequestDTO)).thenReturn(expectedEntity);
            when(travelRequestRepository.save(expectedEntity)).thenReturn(addedEntity);
            when(travelRequestMapper.toDTO(addedEntity)).thenReturn(expectedDTO);

            //Call the service
            TravelRequestDTO resultDTO = travelRequestService.addTravelRequest(travelRequestDTO);

            assertEquals(expectedDTO, resultDTO);
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void testAddTravelRequestNegative_InvalidDate(){
        int employeeId = 1;
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.minusDays(1);

        TravelRequestDTO travelRequestDTO = new TravelRequestDTO();
        travelRequestDTO.setRaisedByEmployeeId(employeeId);
        travelRequestDTO.setFromDate(fromDate);
        travelRequestDTO.setToDate(toDate);
        travelRequestDTO.setPriority(Priority.PRIORITY_1);
        //Entity returned by mapper
        TravelRequest expectedEntity = new TravelRequest();
        expectedEntity.setRaisedByEmployeeId(employeeId);

        when(travelRequestMapper.toEntity(travelRequestDTO)).thenReturn(expectedEntity);
        when(travelRequestRepository.save(expectedEntity)).thenReturn(expectedEntity);
        assertThrows(InvalidDateException.class,()->travelRequestService.addTravelRequest(travelRequestDTO));
    }

    @Test
    void testAddTravelRequestNegative_InvalidPriority(){
        int employeeId = 1;
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.plusDays(30);

        TravelRequestDTO travelRequestDTO = new TravelRequestDTO();
        travelRequestDTO.setRequestId(employeeId);
        travelRequestDTO.setFromDate(fromDate);
        travelRequestDTO.setToDate(toDate);
        travelRequestDTO.setPriority(Priority.INVALID);

        TravelRequest expectedEntity = new TravelRequest();
        expectedEntity.setRequestId(employeeId);

        when(travelRequestMapper.toEntity(travelRequestDTO)).thenReturn(expectedEntity);
        when(travelRequestRepository.save(expectedEntity)).thenReturn(expectedEntity);

        assertThrows(InvalidPriorityException.class,()->travelRequestService.addTravelRequest(travelRequestDTO));

    }

    //TESTING GET_TRAVEL_REQUEST_BY_ID
    @Test
    void testGetTravelRequestByIdPositive_IdExists_BudgetExists(){
        try {
            int requestId = 1;
            int budget = 10000;
            ModeOfTravel modeOfTravel = ModeOfTravel.AIR;
            HotelStarRating hotelStarRating = HotelStarRating.STAR_5;
            RequestStatus requestStatus = RequestStatus.APPROVED;

            TravelRequest travelRequest = TravelRequest.builder()
                    .requestId(requestId)
                    .requestStatus(requestStatus)
                    .build();

            //will be returned by getBudgetAllocationsForTravelRequest
            TravelBudgetAllocationDTO travelBudgetAllocationDTO = TravelBudgetAllocationDTO.builder()
                    .travelRequestId(requestId)
                    .approvedBudget(budget)
                    .approvedModeOfTravel(modeOfTravel)
                    .approvedHotelStarRating(hotelStarRating)
                    .build();

            //will be returned by mapper
            TravelRequestDetailsDTO expectedDTO = TravelRequestDetailsDTO.builder()
                    .requestId(requestId)
                    .requestStatus(requestStatus)
                    .approvedBudget(budget)
                    .approvedModeOfTravel(modeOfTravel)
                    .approvedHotelStarRating(hotelStarRating)
                    .build();

            when(travelRequestRepository.findById(requestId)).thenReturn(Optional.of(travelRequest));
            when(travelBudgetAllocationRepository.existsByTravelRequest(travelRequest)).thenReturn(true);
            when(travelBudgetAllocationService.getBudgetAllocationsForTravelRequest(requestId)).thenReturn(travelBudgetAllocationDTO);
            when(travelRequestDetailsMapper.toDTO(travelRequest,travelBudgetAllocationDTO)).thenReturn(expectedDTO);

            TravelRequestDetailsDTO resultDTO = travelRequestService.getTravelRequestById(requestId);

            assertEquals(expectedDTO,resultDTO);

        }catch (Exception e){
            fail();
        }
    }

    @Test
    void testGetTravelRequestByIdPositive_IdExists_BudgetDoesNotExist() {
        try{
            int requestId = 1;
            RequestStatus requestStatus = RequestStatus.REJECTED;
            TravelRequest travelRequest = TravelRequest.builder()
                    .requestId(requestId)
                    .requestStatus(requestStatus)
                    .build();

            TravelRequestDetailsDTO expectedDTO = TravelRequestDetailsDTO.builder()
                    .requestId(requestId)
                    .requestStatus(requestStatus)
                    .build();

            when(travelBudgetAllocationRepository.existsByTravelRequest(travelRequest)).thenReturn(false);
            when(travelRequestRepository.findById(requestId)).thenReturn(Optional.of(travelRequest));
            when(travelRequestDetailsMapper.toDTO(travelRequest)).thenReturn(expectedDTO);

            TravelRequestDetailsDTO resultDTO = travelRequestService.getTravelRequestById(requestId);

            assertEquals(expectedDTO, resultDTO);

        }catch (Exception e){
            fail();
        }
    }

    @Test
    void testGetTravelRequestByIdNegative_IdDoesNotExist(){
        int requestId = 1;
        when(travelRequestRepository.findById(requestId)).thenReturn(Optional.empty());
        assertThrows(TravelRequestNotFoundException.class,()->travelRequestService.getTravelRequestById(requestId));
    }

    //TESTING GET_PENDING_TRAVEL_REQUESTS_FOR_HR
    @Test
    void testGetPendingTravelRequestsForHRPositive_HrIdExists() {
        try {
            int hrId = 5;
            int requestId1 = 1;
            int requestId2 = 2;
            TravelRequest travelRequest1 = new TravelRequest();
            travelRequest1.setRequestId(requestId1);
            travelRequest1.setToBeApprovedByHRId(hrId);
            travelRequest1.setRequestStatus(RequestStatus.NEW);

            TravelRequest travelRequest2 = new TravelRequest();
            travelRequest2.setRequestId(requestId2);
            travelRequest2.setToBeApprovedByHRId(hrId);
            travelRequest2.setRequestStatus(RequestStatus.NEW);

            //Expected requests DTO after getting from the mock travelRequestMapper
            TravelRequestDTO expectedDTO1 = new TravelRequestDTO();
            expectedDTO1.setRequestId(requestId1);
            expectedDTO1.setToBeApprovedByHRId(hrId);
            expectedDTO1.setRequestStatus(RequestStatus.NEW);

            TravelRequestDTO expectedDTO2 = new TravelRequestDTO();
            expectedDTO2.setRequestId(requestId2);
            expectedDTO2.setToBeApprovedByHRId(hrId);
            expectedDTO2.setRequestStatus(RequestStatus.NEW);

            List<TravelRequest> travelRequestList = List.of(travelRequest1, travelRequest2);
            List<TravelRequestDTO> expectedDTOList = List.of(expectedDTO1, expectedDTO2);

            when(travelRequestRepository.existsByToBeApprovedByHRId(hrId)).thenReturn(true);
            when(travelRequestRepository.findByRequestStatusAndToBeApprovedByHRId(RequestStatus.NEW,hrId)).thenReturn(travelRequestList);
            when(travelRequestMapper.toDTO(any(TravelRequest.class))).thenAnswer(invocation -> {
                TravelRequest request = invocation.getArgument(0);
                if(request.getRequestId() == 1) return expectedDTO1;
                if(request.getRequestId() == 2) return expectedDTO2;
                return null;
            });
            //Call the service class
            List<TravelRequestDTO> result = travelRequestService.getPendingTravelRequestsForHR(hrId);

            assertEquals(expectedDTOList, result);
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void testGetPendingTravelRequestsForHRNegative_HrIdDoesNotExist(){
        int hrId = 1;
        when(travelRequestRepository.existsByToBeApprovedByHRId(hrId)).thenReturn(false);
        assertThrows(HrIdNotFoundException.class,()->travelRequestService.getPendingTravelRequestsForHR(hrId));
    }

    //TESTING OF APPROVE_OR_REJECT_REQUEST
    @Test
    void testApproveOrRejectRequest_Approve(){
        int requestId = 1;
        UpdateTravelRequestDTO updateDTO = new UpdateTravelRequestDTO();
        updateDTO.setRequestStatus(RequestStatus.APPROVED);
        updateDTO.setBudgetPerDay(10000);
        updateDTO.setApprovedModeOfTravel(ModeOfTravel.AIR);
        updateDTO.setApprovedHotelStarRating(HotelStarRating.STAR_5);
        updateDTO.setGrade(Grade.GRADE_1);
        updateDTO.setRole(Role.HR);

        //since the travelRequestService is not a mock object it is declared a Spy for partial mock
        doNothing().when(travelRequestService).approveRequest(requestId);

        travelRequestService.approveOrRejectRequest(requestId,updateDTO);

        verify(travelRequestService).approveRequest(requestId);
    }

    @Test
    void testApproveOrRejectRequest_Reject(){
        int requestId = 1;
        UpdateTravelRequestDTO updateDTO = new UpdateTravelRequestDTO();
        updateDTO.setRequestStatus(RequestStatus.REJECTED);

        doNothing().when(travelRequestService).rejectRequest(requestId);

        travelRequestService.approveOrRejectRequest(requestId,updateDTO);

        verify(travelRequestService).rejectRequest(requestId);
    }

    //TESTING OF APPROVE REQUEST
    @Test
    void testApproveRequestPositive_IdExists(){
        try{
            int requestId = 1;

            ArgumentCaptor<TravelRequest>captor = ArgumentCaptor.forClass(TravelRequest.class);

            TravelRequest travelRequest = TravelRequest.builder()
                    .requestId(requestId)
                    .requestStatus(RequestStatus.NEW)
                    .build();

            when(travelRequestRepository.findById(requestId)).thenReturn(Optional.of(travelRequest));

            travelRequestService.approveRequest(requestId);

            //to verify if the request status is updated to rejected
            verify(travelRequestRepository).save(captor.capture());
            assertEquals(RequestStatus.APPROVED,captor.getValue().getRequestStatus());
        }catch(Exception e){
            fail();
        }
    }

    @Test
    void testApproveRequestNegative_IdDoesNotExist(){
        int requestId = 1;
        when(travelRequestRepository.findById(requestId)).thenReturn(Optional.empty());
        assertThrows(TravelRequestNotFoundException.class, ()->travelRequestService.approveRequest(requestId));
    }

    //TESTING OF REJECT REQUEST
    @Test
    void testRejectRequestPositive_IdExists() {
        try{
            int requestId = 1;

            ArgumentCaptor<TravelRequest>captor = ArgumentCaptor.forClass(TravelRequest.class);

            TravelRequest travelRequest = new TravelRequest();
            travelRequest.setRequestId(requestId);
            travelRequest.setRequestStatus(RequestStatus.NEW);

            when(travelRequestRepository.findById(requestId)).thenReturn(Optional.of(travelRequest));

            travelRequestService.rejectRequest(requestId);

            //to verify if the request status is updated to rejected
            verify(travelRequestRepository).save(captor.capture());
            assertEquals(RequestStatus.REJECTED,captor.getValue().getRequestStatus());
        }catch(Exception e){
            fail();
        }
    }

    @Test
    void testRejectRequestNegative_IdDoesNotExist(){
        int requestId = 1;
        when(travelRequestRepository.findById(requestId)).thenReturn(Optional.empty());
        assertThrows(TravelRequestNotFoundException.class, ()->travelRequestService.rejectRequest(requestId));
    }

    //TESTING OF VALIDATE_DATE
    @Test
    void testValidateDate_ValidDates(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(5);
            assertDoesNotThrow(()->travelRequestService.validateDate(fromDate, toDate));
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void testValidateDate_InvalidDates(){

        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.minusDays(5);
        assertThrows(InvalidDateException.class, ()->travelRequestService.validateDate(fromDate, toDate));
    }

    @Test
    void testValidateDate_InvalidDates_FromDateBeforeNow(){
        LocalDate now = LocalDate.now();
        LocalDate fromDate = now.minusDays(1);
        LocalDate toDate = fromDate.plusDays(10);
        assertThrows(InvalidDateException.class, ()->travelRequestService.validateDate(fromDate, toDate));
    }

    @Test
    void testValidateDate_SameDates(){

        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = LocalDate.now();
        assertThrows(InvalidDateException.class, ()->travelRequestService.validateDate(fromDate, toDate));
    }

    //TESTING OF CALCULATE_TOTAL_DAYS
    @Test
    void testCalculateTotalDays_ValidDates(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(5);
            int totalDays = travelRequestService.calculateTotalDays(fromDate,toDate);
            assertEquals(5,totalDays);
        }catch (Exception e){
            fail();
        }

    }


    //TESTING OF VALIDATE_PRIORITY
    @Test
    void validatePriorityPositive_Priority1(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(30);
            Priority priority = Priority.PRIORITY_1;
            assertDoesNotThrow(()->travelRequestService.validatePriority(fromDate, toDate, priority));
        } catch(Exception e){
            fail();
        }
    }

    @Test
    void validatePriorityNegative_Priority1(){
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.plusDays(31);
        Priority priority = Priority.PRIORITY_1;
        assertThrows(InvalidPriorityException.class,()->travelRequestService.validatePriority(fromDate, toDate, priority));
    }

    @Test
    void validatePriorityPositive_Priority2(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(20);
            Priority priority = Priority.PRIORITY_2;
            assertDoesNotThrow(()->travelRequestService.validatePriority(fromDate, toDate, priority));
        } catch(Exception e){
            fail();
        }
    }

    @Test
    void validatePriorityNegative_Priority2(){
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.plusDays(21);
        Priority priority = Priority.PRIORITY_2;
        assertThrows(InvalidPriorityException.class,()->travelRequestService.validatePriority(fromDate, toDate, priority));
    }

    @Test
    void validatePriorityPositive_Priority3(){
        try{
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(10);
            Priority priority = Priority.PRIORITY_3;
            assertDoesNotThrow(()->travelRequestService.validatePriority(fromDate, toDate, priority));
        } catch(Exception e){
            fail();
        }
    }

    @Test
    void validatePriorityNegative_Priority3(){
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.plusDays(11);
        Priority priority = Priority.PRIORITY_3;
        assertThrows(InvalidPriorityException.class,()->travelRequestService.validatePriority(fromDate, toDate, priority));
    }

    @Test
    void validatePriorityDefault_PriorityInvalid(){
        LocalDate fromDate = LocalDate.now();
        LocalDate toDate = fromDate.plusDays(11);
        Priority invalidPriority = Priority.INVALID;
        assertThrows(InvalidPriorityException.class,()->travelRequestService.validatePriority(fromDate, toDate, invalidPriority));
    }


}

/*@Captor is an annotation in the mockito library that is used
alongside the ArgumentCaptor class to capture arguments that are
passed to the methods of mocked objects. It is always used alongside
verify() to retrieve the arguments that were passed when a method from
a mocked dependency is called. It is a useful tool that can enable
us to create extra assertions to our tests and therefore make our
unit tests more accurate.*/