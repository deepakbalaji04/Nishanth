package com.cognizant.controller;

import com.cognizant.dto.LocationDTO;
import com.cognizant.dto.TravelRequestDTO;
import com.cognizant.dto.TravelRequestDetailsDTO;
import com.cognizant.dto.UpdateTravelRequestDTO;
import com.cognizant.exception.*;
import com.cognizant.service.impl.LocationServiceImpl;
import com.cognizant.service.impl.TravelBudgetAllocationServiceImpl;
import com.cognizant.service.impl.TravelRequestServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.*;


class TravelRequestControllerTest {

    @Mock
    private LocationServiceImpl locationService;
    @Mock
    private TravelRequestServiceImpl travelRequestService;
    @Mock
    private TravelBudgetAllocationServiceImpl travelBudgetAllocationService;

    @InjectMocks
    private TravelRequestController travelRequestController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    //TESTING OF GET ALL LOCATIONS
    @Test
    void getAllLocationsPositive() {
        try {
            List<LocationDTO>locationDTOList = List.of(new LocationDTO(1, "Location 1"), new LocationDTO(2,"Location 2"));
            when(locationService.getAllLocationsDTO()).thenReturn(locationDTOList);

            ResponseEntity<?>responseEntity = travelRequestController.getAllLocations();

            assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
            assertEquals(locationDTOList, responseEntity.getBody());
        } catch (Exception e) {
            fail();
        }

    }

    //TESTING OF ADD TRAVEL REQUEST
    @Test
    void addTravelRequestPositive() {
        try {
            int id = 1;
            TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                    .requestId(id)
                    .build();

            when(travelRequestService.addTravelRequest(travelRequestDTO)).thenReturn(travelRequestDTO);

            ResponseEntity<?>responseEntity = travelRequestController.addTravelRequest(travelRequestDTO);

            assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
            assertEquals(travelRequestDTO,responseEntity.getBody());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    void addTravelRequestNegative_InvalidDate(){
        int id = 1;
        TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                .requestId(id)
                .build();
        when(travelRequestService.addTravelRequest(travelRequestDTO)).thenThrow(InvalidDateException.class);

        ResponseEntity<?>responseEntity = travelRequestController.addTravelRequest(travelRequestDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void addTravelRequestNegative_InvalidPriority(){
        int id = 1;
        TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                .requestId(id)
                .build();
        when(travelRequestService.addTravelRequest(travelRequestDTO)).thenThrow(InvalidPriorityException.class);

        ResponseEntity<?>responseEntity = travelRequestController.addTravelRequest(travelRequestDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    //TESTING OF GET TRAVEL REQUEST BY ID
    @Test
    void getTravelRequestByIdPositive() {
        try{
            int id = 1;
            TravelRequestDetailsDTO travelRequestDetailsDTO = TravelRequestDetailsDTO.builder()
                    .requestId(id)
                    .build();
            when(travelRequestService.getTravelRequestById(id)).thenReturn(travelRequestDetailsDTO);

            ResponseEntity<?>responseEntity = travelRequestController.getTravelRequestById(id);

            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
            assertEquals(travelRequestDetailsDTO, responseEntity.getBody());

        }catch(Exception e){
            fail();
        }
    }

    @Test
    void getTravelRequestByIdNegative_IdNotFound(){
        int id = 1;
        when(travelRequestService.getTravelRequestById(id)).thenThrow(TravelRequestNotFoundException.class);

        ResponseEntity<?>responseEntity = travelRequestController.getTravelRequestById(id);

        assertEquals(HttpStatus.NOT_FOUND,responseEntity.getStatusCode());
    }

    //TESTING OF GET PENDING TRAVEL REQUESTS
    @Test
    void getPendingTravelRequestsForHRPositive() {
        try{
            int requestId = 1;
            int hrId = 10;
            TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                    .requestId(requestId)
                    .toBeApprovedByHRId(hrId)
                    .build();
            List<TravelRequestDTO>travelRequestDTOList = new ArrayList<>();
            travelRequestDTOList.add(travelRequestDTO);

            when(travelRequestService.getPendingTravelRequestsForHR(hrId)).thenReturn(travelRequestDTOList);
            ResponseEntity<?>responseEntity = travelRequestController.getPendingTravelRequestsForHR(hrId);
            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
            assertEquals(travelRequestDTOList, responseEntity.getBody());
        }catch (Exception e){
            fail();
        }
    }

    @Test
    void getPendingTravelRequestsForHRNegative_HrIdNotFound(){
        int requestId = 1;
        int hrId = 10;
        TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                .requestId(requestId)
                .toBeApprovedByHRId(hrId)
                .build();
        List<TravelRequestDTO>travelRequestDTOList = new ArrayList<>();
        travelRequestDTOList.add(travelRequestDTO);

        when(travelRequestService.getPendingTravelRequestsForHR(hrId)).thenThrow(HrIdNotFoundException.class);
        ResponseEntity<?>responseEntity = travelRequestController.getPendingTravelRequestsForHR(hrId);
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }

    //TESTING OF APPROVE/REJECT REQUEST
    @Test
    void approveRequestOrRejectRequestPositive() {
        try {
            int id = 1;
            UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                    .requestId(id)
                    .build();
            doNothing().when(travelRequestService).approveOrRejectRequest(id,updateTravelRequestDTO);

            ResponseEntity<?>responseEntity = travelRequestController.approveRequestOrRejectRequest(id,updateTravelRequestDTO);
            verify(travelRequestService).approveOrRejectRequest(id,updateTravelRequestDTO);
            assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    void approveRequestOrRejectRequestNegative_InvalidHotel(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidHotelStarRatingException.class).when(travelRequestService).approveOrRejectRequest(id, updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.approveRequestOrRejectRequest(id, updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void approveRequestOrRejectRequestNegative_InvalidBudget(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidBudgetException.class).when(travelRequestService).approveOrRejectRequest(id, updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.approveRequestOrRejectRequest(id, updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void approveRequestOrRejectRequestNegative_InvalidGrade(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidGradeException.class).when(travelRequestService).approveOrRejectRequest(id, updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.approveRequestOrRejectRequest(id, updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void approveRequestOrRejectRequestNegative_TravelRequestNotFound(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(TravelRequestNotFoundException.class).when(travelRequestService).approveOrRejectRequest(id, updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.approveRequestOrRejectRequest(id, updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    //TESTING OF CALCULATING BUDGET
    @Test
    void calculateBudgetPositive() {
        try {
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusDays(1);
            int budgetPerDay = 100;
            TravelRequestDTO travelRequestDTO = TravelRequestDTO.builder()
                    .fromDate(fromDate)
                    .toDate(toDate)
                    .budgetPerDay(budgetPerDay)
                    .build();

            when(travelBudgetAllocationService.calculateBudget(travelRequestDTO)).thenReturn(100);

            ResponseEntity<?>responseEntity = travelRequestController.calculateBudget(travelRequestDTO);
            assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
            assertEquals(budgetPerDay, responseEntity.getBody());
        } catch (Exception e) {
            fail();
        }
    }

    //TESTING OF ASSIGNING BUDGET
    @Test
    void assignBudgetPositive() {
        try {
            int id = 1;
            UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                    .requestId(id)
                    .build();
            doNothing().when(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);

            ResponseEntity<?>responseEntity = travelRequestController.assignBudget(updateTravelRequestDTO);
            verify(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);
            assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    void assignBudgetNegative_InvalidHotel(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidHotelStarRatingException.class).when(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.assignBudget(updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void assignBudgetNegative_InvalidBudget(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidBudgetException.class).when(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.assignBudget(updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void assignBudgetNegative_InvalidGrade(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(InvalidGradeException.class).when(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.assignBudget(updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

    @Test
    void assignBudgetNegative_BudgetAlreadyExists(){
        int id = 1;
        UpdateTravelRequestDTO updateTravelRequestDTO = UpdateTravelRequestDTO.builder()
                .requestId(id)
                .build();
        doThrow(BudgetAlreadyExistsException.class).when(travelBudgetAllocationService).assignBudget(updateTravelRequestDTO);
        ResponseEntity<?>responseEntity = travelRequestController.assignBudget(updateTravelRequestDTO);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, responseEntity.getStatusCode());
    }

}