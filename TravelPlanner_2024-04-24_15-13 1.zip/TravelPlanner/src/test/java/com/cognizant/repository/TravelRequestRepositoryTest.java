package com.cognizant.repository;

import com.cognizant.entities.Location;
import com.cognizant.entities.Priority;
import com.cognizant.entities.RequestStatus;
import com.cognizant.entities.TravelRequest;
import com.cognizant.TravelPlannerApplication;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@DataJpaTest
@ContextConfiguration(classes = TravelPlannerApplication.class)
class TravelRequestRepositoryTest {
    @Autowired
    private TravelRequestRepository travelRequestRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllPositive(){
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);
        travelRequest.setRequestRaisedOn(LocalDate.parse("2024-06-11"));
        travelRequest.setFromDate(LocalDate.parse("2022-12-12"));
        travelRequest.setToDate(LocalDate.parse("2024-12-12"));
        travelRequest.setPurposeOfTravel("testPurpose");
        travelRequest.setLocation(null);
        travelRequest.setRequestStatus(RequestStatus.valueOf("NEW"));
        travelRequest.setRequestApprovedOn(LocalDate.parse("2022-12-31"));
        travelRequest.setPriority(Priority.valueOf("PRIORITY_1"));
        entityManager.persist(travelRequest);
        Iterable<TravelRequest> it = travelRequestRepository.findAll();
        assertTrue(it.iterator().hasNext());
    }

    @Test
    void testFindAllNegative(){
        Iterable<TravelRequest>it = travelRequestRepository.findAll();
        assertFalse(it.iterator().hasNext());
    }

    @Test
    void testFindByIdPositive(){
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);
        travelRequest.setRequestRaisedOn(LocalDate.parse("2024-06-11"));
        travelRequest.setFromDate(LocalDate.parse("2022-12-12"));
        travelRequest.setToDate(LocalDate.parse("2024-12-12"));
        travelRequest.setPurposeOfTravel("testPurpose");
        travelRequest.setLocation(null);
        travelRequest.setRequestStatus(RequestStatus.valueOf("NEW"));
        travelRequest.setRequestApprovedOn(LocalDate.parse("2022-12-31"));
        travelRequest.setPriority(Priority.valueOf("PRIORITY_1"));
        entityManager.persist(travelRequest);
        Optional<TravelRequest> travelRequests = travelRequestRepository.findById(travelRequest.getRequestId());
        assertTrue(travelRequests.isPresent());
    }

    @Test
    void testFindByIdNegative(){
        Optional<TravelRequest> travelRequests = travelRequestRepository.findById(1);
        assertFalse(travelRequests.isPresent());
    }

    @Test
    void testSavePositive(){
        TravelRequest travelRequest = new TravelRequest();
        Location location = new Location();
        location.setId(5);

        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);
        travelRequest.setRequestRaisedOn(LocalDate.parse("2024-06-11"));
        travelRequest.setFromDate(LocalDate.parse("2022-12-12"));
        travelRequest.setToDate(LocalDate.parse("2024-12-12"));
        travelRequest.setPurposeOfTravel("testPurpose");
        travelRequest.setLocation(location);
        travelRequest.setRequestStatus(RequestStatus.valueOf("NEW"));
        travelRequest.setRequestApprovedOn(LocalDate.parse("2022-12-31"));
        travelRequest.setPriority(Priority.valueOf("PRIORITY_1"));
        travelRequestRepository.save(travelRequest);
        Optional<TravelRequest> travelRequests = travelRequestRepository.findById(travelRequest.getRequestId());
        assertTrue(travelRequests.isPresent());
    }

    @Test
    void testDeletePositive(){
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);
        travelRequest.setRequestRaisedOn(LocalDate.parse("2024-06-11"));
        travelRequest.setFromDate(LocalDate.parse("2022-12-12"));
        travelRequest.setToDate(LocalDate.parse("2024-12-12"));
        travelRequest.setPurposeOfTravel("testPurpose");
        travelRequest.setLocation(null);
        travelRequest.setRequestStatus(RequestStatus.valueOf("NEW"));
        travelRequest.setRequestApprovedOn(LocalDate.parse("2022-12-31"));
        travelRequest.setPriority(Priority.valueOf("PRIORITY_1"));
        travelRequestRepository.delete(travelRequest);
        Optional<TravelRequest> travelRequests = travelRequestRepository.findById(travelRequest.getRequestId());
        assertTrue(travelRequests.isEmpty());
    }

    @Test
    void testFindByRequestStatusAndToBeApprovedByHRIdPositive(){
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);
        travelRequest.setRequestRaisedOn(LocalDate.parse("2024-06-11"));
        travelRequest.setFromDate(LocalDate.parse("2022-12-12"));
        travelRequest.setToDate(LocalDate.parse("2024-12-12"));
        travelRequest.setPurposeOfTravel("testPurpose");
        travelRequest.setLocation(null);
        travelRequest.setRequestStatus(RequestStatus.valueOf("NEW"));
        travelRequest.setRequestApprovedOn(LocalDate.parse("2022-12-31"));
        travelRequest.setPriority(Priority.valueOf("PRIORITY_1"));
        entityManager.persist(travelRequest);
        List<TravelRequest> res = travelRequestRepository.findByRequestStatusAndToBeApprovedByHRId(travelRequest.getRequestStatus(),travelRequest.getToBeApprovedByHRId());
        assertFalse(res.isEmpty());
    }

    @Test
    void testFindByRequestStatusAndToBeApprovedByHRIdNegative(){
        List<TravelRequest> travelRequests = travelRequestRepository.findByRequestStatusAndToBeApprovedByHRId(RequestStatus.valueOf("NEW"),1);
        assertTrue(travelRequests.isEmpty());
    }

    @Test
    void testExistsByToBeApprovedByHRIdPositive(){
        int hrId = 2;
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(hrId);

        entityManager.persist(travelRequest);

        TravelRequest expectedTravelRequest = new TravelRequest();
        expectedTravelRequest.setRequestId(1);
        expectedTravelRequest.setRaisedByEmployeeId(1);
        expectedTravelRequest.setToBeApprovedByHRId(hrId);

        boolean hrIdExists = travelRequestRepository.existsByToBeApprovedByHRId(hrId);
        assertTrue(hrIdExists);
    }

    @Test
    void testExistsByToBeApprovedByHRIdNegative(){
        int hrId = 5;
        TravelRequest travelRequest = new TravelRequest();
        travelRequest.setRaisedByEmployeeId(1);
        travelRequest.setToBeApprovedByHRId(2);

        entityManager.persist(travelRequest);

        boolean hrIdExists = travelRequestRepository.existsByToBeApprovedByHRId(hrId);
        assertFalse(hrIdExists);
    }

}