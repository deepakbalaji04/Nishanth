package com.cognizant.repository;

import com.cognizant.entities.Location;
import com.cognizant.TravelPlannerApplication;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ContextConfiguration(classes = TravelPlannerApplication.class)
class LocationRepositoryTest {
    @Autowired
    private LocationRepository locationRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllPositive(){
        Location l = new Location();
        l.setName("test");
        entityManager.persist(l);
        Iterable<Location> it = locationRepository.findAll();
        assertTrue(it.iterator().hasNext());
    }

    @Test
    void testFindAllNegative(){
        locationRepository.deleteAll();
        Iterable<Location> l = locationRepository.findAll();
        assertFalse(l.iterator().hasNext());
    }

    @Test
    void testFindByIdPositive(){
        Location l = new Location();
        l.setName("test");
        entityManager.persist(l);
        Optional<Location> locations = locationRepository.findById(l.getId());
        assertTrue(locations.isPresent());
    }

    @Test
    void testFindByIdNegative(){
        locationRepository.deleteAll();
        Optional<Location> l = locationRepository.findById(1);
        assertFalse(l.isPresent());
    }

    @Test
    void testSavePositive(){
        Location l = new Location();
        l.setName("test");
        locationRepository.save(l);
        Optional<Location> locations = locationRepository.findById(l.getId());
        assertTrue(locations.isPresent());
    }

    @Test
    void testDeletePositive(){
        Location l = new Location();
        l.setName("test");
        entityManager.persist(l);
        locationRepository.delete(l);
        Optional<Location> locations = locationRepository.findById(l.getId());
        assertTrue(locations.isEmpty());
    }
}