package com.cognizant.repository;

import com.cognizant.TravelPlannerApplication;
import com.cognizant.entities.HotelStarRating;
import com.cognizant.entities.ModeOfTravel;
import com.cognizant.entities.TravelBudgetAllocation;
import com.cognizant.entities.TravelRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.test.context.ContextConfiguration;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@DataJpaTest
@ContextConfiguration(classes = TravelPlannerApplication.class)
class TravelBudgetAllocationRepositoryTest {
    @Autowired
    private TravelBudgetAllocationRepository travelBudgetAllocationRepository;
    @Autowired
    private TravelRequestRepository travelRequestRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindAllPositive(){
        TravelBudgetAllocation t = new TravelBudgetAllocation();
        t.setTravelRequest(null);
        t.setApprovedBudget(1);
        t.setApprovedModeOfTravel(ModeOfTravel.valueOf("AIR"));
        t.setApprovedHotelStarRating(HotelStarRating.valueOf("STAR_3"));
        entityManager.persist(t);
        Iterable<TravelBudgetAllocation> it = travelBudgetAllocationRepository.findAll();
        assertTrue(it.iterator().hasNext());
    }

    @Test
    void testFindAllNegative(){
        Iterable<TravelBudgetAllocation> t = travelBudgetAllocationRepository.findAll();
        assertFalse(t.iterator().hasNext());
    }

    @Test
    void testFindByIdPositive(){
        TravelBudgetAllocation t = new TravelBudgetAllocation();
        t.setTravelRequest(null);
        t.setApprovedBudget(1);
        t.setApprovedModeOfTravel(ModeOfTravel.valueOf("AIR"));
        t.setApprovedHotelStarRating(HotelStarRating.valueOf("STAR_3"));
        entityManager.persist(t);
        Optional<TravelBudgetAllocation> travelBudgetAllocations = travelBudgetAllocationRepository.findById(t.getId());
        assertTrue(travelBudgetAllocations.isPresent());
    }

    @Test
    void testFindByIdNegative(){
        Optional<TravelBudgetAllocation> t = travelBudgetAllocationRepository.findById(1);
        assertFalse(t.isPresent());
    }

    @Test
    void testSavePositive(){
        TravelBudgetAllocation t = new TravelBudgetAllocation();
        t.setTravelRequest(null);
        t.setApprovedBudget(1);
        t.setApprovedModeOfTravel(ModeOfTravel.valueOf("AIR"));
        t.setApprovedHotelStarRating(HotelStarRating.valueOf("STAR_3"));
        travelBudgetAllocationRepository.save(t);
        Optional<TravelBudgetAllocation> travelBudgetAllocation = travelBudgetAllocationRepository.findById(t.getId());
        assertTrue(travelBudgetAllocation.isPresent());
    }

    @Test
    void testDeletePositive(){
        TravelBudgetAllocation t = new TravelBudgetAllocation();

        t.setTravelRequest(null);
        t.setApprovedBudget(1);
        t.setApprovedModeOfTravel(ModeOfTravel.valueOf("AIR"));
        t.setApprovedHotelStarRating(HotelStarRating.valueOf("STAR_3"));
        travelBudgetAllocationRepository.delete(t);
        Optional<TravelBudgetAllocation> travelBudgetAllocation = travelBudgetAllocationRepository.findById(1);
        assertTrue(travelBudgetAllocation.isEmpty());
    }

    @Test
    void findByTravelRequestPositive(){
        TravelRequest travelRequest1 = new TravelRequest();
        travelRequestRepository.save(travelRequest1);

        TravelRequest travelRequest2 = new TravelRequest();
        travelRequestRepository.save(travelRequest2);

        TravelBudgetAllocation travelBudgetAllocation = new TravelBudgetAllocation();
        travelBudgetAllocation.setTravelRequest(travelRequest2);
        travelBudgetAllocationRepository.save(travelBudgetAllocation);

        Optional<TravelBudgetAllocation> result = travelBudgetAllocationRepository.findByTravelRequest(travelRequest2);

        assertEquals(travelBudgetAllocation,result.get());
    }

    @Test
    void findByTravelRequestNegative(){
        TravelRequest travelRequest = new TravelRequest();
        assertThrows(InvalidDataAccessApiUsageException.class,()->travelBudgetAllocationRepository.findByTravelRequest(travelRequest));
    }
}