import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate{
  constructor(private authService: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):Observable<boolean> | boolean{
    const userRole = this.authService.getCurrentUser();
    
    const authorisedRole = route.data['authorisedRole'];
    if(userRole !== authorisedRole){
      alert('Access Denied');
      this.router.navigate(['/']);
      return false;
    }
    return true;
  }
}
