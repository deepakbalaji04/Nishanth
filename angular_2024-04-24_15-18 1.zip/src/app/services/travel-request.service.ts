import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Location } from '../models/location';
import { FormGroup, NgForm } from '@angular/forms';
import { TravelRequest } from '../models/travelRequest';
import { UpdateRequest } from '../models/updateRequest';
import { TravelRequestDetails } from '../models/travelRequestDetails';

@Injectable({
  providedIn: 'root'
})
export class TravelRequestService {

  constructor(private http: HttpClient) { }

  private retrieveLocationsURL = 'http://localhost:9090/api/travelrequests/locations';
  private addTravelRequestURL = 'http://localhost:9090/api/travelrequests/new';
  private retrievePendingRequestsURL = 'http://localhost:9090/api/travelrequests/';
  private updateRequestURL = 'http://localhost:9090/api/travelrequests/';
  private retrieveTravelRequestsByIdURL = 'http://localhost:9090/api/travelrequests/';
  private calculateBudgetURL = 'http://localhost:9090/api/travelrequests/calculatebudget';
  private assignBudgetURL = 'http://localhost:9090/api/travelrequests/assignbudget'


  public getAllLocations() {
    return this.http.get<Location[]>(this.retrieveLocationsURL);
  }

  public addTravelRequest(form: FormGroup) {
    return this.http.post<TravelRequest>(this.addTravelRequestURL, form)
  }

  public getPendingTravelRequest(hrId: number) {
    return this.http.get<TravelRequest[]>(this.retrievePendingRequestsURL + hrId + '/pending');
  }

  public updateRequest(requestId: number, body: UpdateRequest) {
    return this.http.put<UpdateRequest>(this.updateRequestURL + requestId + '/update', body);
  }

  public getTravelRequestsById(requestId: number) {
    return this.http.get<TravelRequestDetails>(this.retrieveTravelRequestsByIdURL + requestId);
  }

  public calculateBudget(body: any) {
    return this.http.post<number>(this.calculateBudgetURL, body);
  }

  public assignBudget(form: FormGroup) {
    return this.http.post<UpdateRequest>(this.assignBudgetURL, form);
  }
}
