import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private userRole: 'HR' | 'Employee' = 'Employee';

  //BehaviorSubject to hold current role and notify subscribers
  private userRoleSubject: BehaviorSubject<'HR'|'Employee'> = new BehaviorSubject(this.userRole);

  constructor() { 
    this.userRoleSubject.next(this.userRole); // Initialize the subject with the current role
  }

  toggleViewMode(): void{
    this.userRole = this.userRole === 'Employee'?'HR':'Employee';
    this.userRoleSubject.next(this.userRole); // Notify subscribers of the role change
  }

  getUserRole(): Observable<'HR'|'Employee'>{
    return this.userRoleSubject.asObservable(); //Return an Observable of the current role
  }


  getCurrentUser(): 'HR'|'Employee'{
    return this.userRole;
  }
}
