import { Component } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent{
  isHR: boolean = false;
  isEmployee: boolean = false;

  constructor(private authService: AuthenticationService){
    this.authService.getUserRole().subscribe((role: 'HR'|'Employee') =>{
      this.isHR = role === 'HR';
      this.isEmployee = role === 'Employee';
    })
  }

}
