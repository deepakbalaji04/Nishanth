import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TravelRequestDetails } from 'src/app/models/travelRequestDetails';
import { TravelRequestService } from 'src/app/services/travel-request.service';
import { Location } from 'src/app/models/location';

@Component({
  selector: 'app-travel-request-details',
  templateUrl: './travel-request-details.component.html',
  styleUrls: ['./travel-request-details.component.css']
})
export class TravelRequestDetailsComponent {

  travelRequestDetails = {} as TravelRequestDetails;
  locations: Location[] = [];
  searched: boolean = false;
  errorMessage: string = '';
  errorStatus: boolean = false;

  searchDetailsForm: FormGroup;

  constructor(private travelRequestService: TravelRequestService, private formBuilder: FormBuilder) {
    this.searchDetailsForm = this.formBuilder.group({
      "requestId": [null, [Validators.required, Validators.min(1), Validators.max(9999999)]]
    });
  }

  ngOnInit() {
    this.fetchLocations();
  }

  onSearch() {
    const requestId = this.searchDetailsForm.get('requestId')!.value;
    this.fetchTravelRequestDetails(requestId);
  }

  fetchTravelRequestDetails(requestId: number) {
    this.travelRequestService.getTravelRequestsById(requestId)
      .subscribe({
        next: responseData =>{
          this.travelRequestDetails = responseData;
          this.searched = true;
          this.errorStatus = false;
        },
        error: msg =>{
          this.errorMessage = msg.error;
          this.errorStatus = true;
        }
      });
  }

  fetchLocations() {
    this.travelRequestService.getAllLocations()
      .subscribe(responseData => {
        this.locations = responseData;
      })
  }

  getLocationName(locationId: number) {
    const location: Location | undefined = this.locations.find(loc => loc.locationId === locationId);
    return location?.locationName;
  }

  displayError(controlName: string, errorName: string) {
    const control = this.searchDetailsForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }

  //to prevent user from entering anything other than numbers
  onKeydown(event:KeyboardEvent){
    const invalidCharacters = ['.','e','+','E'];
    if(invalidCharacters.includes(event.key)){
      event?.preventDefault();
    }
  }
}
