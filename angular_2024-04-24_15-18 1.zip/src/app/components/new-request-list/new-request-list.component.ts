import { Component, OnInit } from '@angular/core';
import { TravelRequestService } from 'src/app/services/travel-request.service';
import { TravelRequest } from 'src/app/models/travelRequest';
import { Location } from 'src/app/models/location';
import { UpdateRequest } from '../../models/updateRequest';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-new-request-list',
  templateUrl: './new-request-list.component.html',
  standalone:false,
  styleUrls: ['./new-request-list.component.css'],
})
export class NewRequestListComponent implements OnInit{
  locations:Location[] = [];
  pendingTravelRequests:TravelRequest[]=[];
  pendingRequestSearchForm: FormGroup;
  p:number = 1;
  hrIdTemp!:number;
  searched: boolean = false;
  errorMessage: string = '';
  errorStatus: boolean = false;

  constructor(private travelRequestService: TravelRequestService, private formBuilder: FormBuilder) {
    this.pendingRequestSearchForm = this.formBuilder.group({
      "hrId":[null,[Validators.required, Validators.pattern(/^\d{7}$/), Validators.min(0)]]
    });
  }

  ngOnInit(){
    this.fetchLocations();
  }
  
  fetchLocations() {
    this.travelRequestService.getAllLocations()
      .subscribe(responseData => {
        this.locations = responseData;
      })
  }

  getLocationName(locationId:number){
    const location:Location|undefined = this.locations.find(loc => loc.locationId === locationId);
    return location?.locationName;
  }
  
  fetchPendingRequests(hrId:number){
    this.travelRequestService.getPendingTravelRequest(hrId)
    .subscribe({
      next: responseData => {
        this.pendingTravelRequests = responseData;
        this.hrIdTemp = hrId;
        this.searched = true;
        this.errorStatus = false;
      },
      error: msg =>{
        this.errorMessage = msg.error;
        this.errorStatus = true;
      }
    });
  }

  searchRequests(){
    if(this.pendingRequestSearchForm.valid){
      const hrId = this.pendingRequestSearchForm.get('hrId')!.value;
      this.fetchPendingRequests(hrId);
    }
  }
  //for rejecting the request
  rejectRequest(requestId:number){
    const body:UpdateRequest = {
      "requestStatus": "REJECTED",
    };
    this.travelRequestService.updateRequest(requestId,body)
    .subscribe(responseData =>{
      console.log("Rejected Successfully");
      this.fetchPendingRequests(this.hrIdTemp);
    })
  }

  displayError(controlName: string, errorName: string){
    const control = this.pendingRequestSearchForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }

  onKeydown(event:KeyboardEvent){
    const invalidCharacters = ['.','e','+','E'];
    if(invalidCharacters.includes(event.key)){
      event?.preventDefault();
    }
  }
}


