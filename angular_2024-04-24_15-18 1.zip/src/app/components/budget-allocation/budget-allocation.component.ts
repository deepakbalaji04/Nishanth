import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TravelRequestService } from 'src/app/services/travel-request.service';
import { Location } from 'src/app/models/location';
import { UpdateRequest } from 'src/app/models/updateRequest';
import { TravelRequestDetails } from 'src/app/models/travelRequestDetails';

@Component({
  selector: 'app-travel-request-details',
  templateUrl: './budget-allocation.component.html',
  styleUrls: ['./budget-allocation.component.css']
})
export class BudgetAllocationComponent implements OnInit {

  requestId: number;
  totalBudget: number = 0;
  modeOfTravel: String[] = ['AIR', 'TRAIN', 'BUS'];
  hotelStarRating: String[] = ['STAR_3', 'STAR_5', 'STAR_7'];
  grades: String[] = ['GRADE_1', 'GRADE_2', 'GRADE_3'];
  roles: String[] = ['EMPLOYEE', 'HR', 'TRAVEL_DESK_EXE'];

  budgetAllocationForm: FormGroup;

  travelRequestDetails = {} as TravelRequestDetails;
  locations: Location[] = [];

  assignedStatus: boolean = false;
  errorMessage: string = '';
  errorStatus: boolean = false;

  assignedSuccessMessage: string = 'Success!! Approved and assigned Successfully ';

  constructor(private route: ActivatedRoute, private travelRequestService: TravelRequestService, private formBuilder: FormBuilder) {
    this.requestId = this.route.snapshot.params['trid'];

    this.budgetAllocationForm = this.formBuilder.group({
      "requestId": [this.requestId, Validators.required],
      "budgetPerDay": [null, [Validators.required, Validators.min(1), Validators.max(15000)]],
      "approvedBudget": [null, [Validators.required, Validators.min(1), Validators.max(450000)]],
      "approvedModeOfTravel": [null, Validators.required],
      "approvedHotelStarRating": [null, Validators.required],
      "grade": [null, Validators.required],
      "role": [null, Validators.required],
    });
  }

  ngOnInit() {
    this.fetchLocations();
    this.fetchTravelRequestDetails(this.requestId);
  }

  fetchTravelRequestDetails(requestId: number) {
    this.travelRequestService.getTravelRequestsById(requestId)
      .subscribe(responseData => {
        this.travelRequestDetails = responseData;
      });
  }

  fetchLocations() {
    this.travelRequestService.getAllLocations()
      .subscribe(responseData => {
        this.locations = responseData;
      })
  }

  getLocationName(locationId: number) {
    const location: Location | undefined = this.locations.find(loc => loc.locationId === locationId);
    return location?.locationName;
  }

  //for fetching the total budget
  fetchTotalBudget(event: KeyboardEvent) {
    const body = {
      "fromDate": this.travelRequestDetails.fromDate,
      "toDate": this.travelRequestDetails.toDate,
      "budgetPerDay": (event.target as HTMLInputElement).value
    }
    this.travelRequestService.calculateBudget(body)
      .subscribe(responseData => {
        this.totalBudget = responseData;
        this.budgetAllocationForm.patchValue({ "approvedBudget": this.totalBudget });
      })
  }
  //after submitting it will assign budget and set status as approved
  onSubmit() {
    const body: UpdateRequest = {
      "requestStatus": "APPROVED",
    };

    this.travelRequestService.assignBudget(this.budgetAllocationForm.value)
      .subscribe({
        next: ()=>{
          this.travelRequestService.updateRequest(this.requestId, body)
            .subscribe(()=>{
              this.assignedStatus = true;
            });
        },
        error: msg =>{
          this.errorMessage = msg.error;
          this.errorStatus = true;
        }
      })
      
    this.budgetAllocationForm.reset();
  }

  displayError(controlName: string, errorName: string) {
    const control = this.budgetAllocationForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }

  onKeydown(event:KeyboardEvent){
    const invalidCharacters = ['.','e','+','E'];
    if(invalidCharacters.includes(event.key)){
      event?.preventDefault();
    }
  }
}
