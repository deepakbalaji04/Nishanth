import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from 'src/app/models/location';
import { TravelRequestService } from 'src/app/services/travel-request.service';


@Component({
  selector: 'app-new-travel-request',
  templateUrl: './new-travel-request.component.html',
  styleUrls: ['./new-travel-request.component.css'],
})

export class NewTravelRequestComponent implements OnInit{

  locations: Location[] = [];
  travelRequestIdGenerated: number = 0;
  newTravelRequestForm: FormGroup;
  currentDate!:string;
  minToDate:String|null= null;
  maxToDate:String|null = null;
  isToDateDisabled:boolean = true;
  submitted:boolean = false;
  errorMessage: string = "";
  errorStatus: boolean = false;

  constructor(private travelRequestService: TravelRequestService, private formBuilder: FormBuilder) {
    this.newTravelRequestForm = this.formBuilder.group({
      "raisedByEmployeeId": [null, [Validators.required, Validators.pattern(/^\d{7}$/), Validators.min(0)]],
      "toBeApprovedByHRId": [2317000, [Validators.required, Validators.pattern(/^\d{7}$/), Validators.min(0)]],
      "fromDate": [null, [Validators.required]],
      "toDate": [{value:null,disabled:true}, [Validators.required]],
      "purposeOfTravel": [null, [Validators.required, Validators.maxLength(100)]],
      "locationId": [null, Validators.required],
      "priority": [null, Validators.required]
    });
    
  }

  ngOnInit() {
    //for fetching the locations from backend for the dropdown
    this.fetchLocations();

    //to set the current date as min date for from date
    const today = new Date();
    this.currentDate = today.toISOString().split('T')[0];
    
    //To set the toDate value as atleast one day from fromDate and max date as 30 days
    this.newTravelRequestForm.get("fromDate")!.valueChanges.subscribe(fromDate =>{
      if(fromDate){
        const minDate = new Date(fromDate);
        const maxDate = new Date(fromDate);
        minDate.setDate(minDate.getDate()+1);
        maxDate.setDate(maxDate.getDate()+30);
  
        this.minToDate = minDate.toISOString().split('T')[0];
        this.maxToDate = maxDate.toISOString().split('T')[0];

        this.newTravelRequestForm.get("toDate")?.setValue(null);
        this.newTravelRequestForm.get("toDate")?.enable();
      }else{
        //toDate will be disabled initially or when from date is null
        this.newTravelRequestForm.get("toDate")?.disable();
        this.newTravelRequestForm.get("toDate")?.setValue(null);
        this.minToDate = null;
        this.maxToDate = null;
      }
    });
  }

  onSubmit() {
    if(this.newTravelRequestForm.valid){

      this.travelRequestService.addTravelRequest(this.newTravelRequestForm.value)
        .subscribe({
          next: responseData =>{
            this.travelRequestIdGenerated = responseData.requestId;
            this.submitted = true;
          },
          error: msg =>{
            this.errorMessage = msg.error;
            this.errorStatus = true;
          }
        });
      this.newTravelRequestForm.reset();
    }
  }

  fetchLocations() {
    this.travelRequestService.getAllLocations()
      .subscribe(responseData => {
        this.locations = responseData;
      })
  }

  displayError(controlName: string, errorName: string){
    const control = this.newTravelRequestForm.get(controlName);
    return control && (control.touched || control.dirty) && control.hasError(errorName);
  }

  onKeydown(event:KeyboardEvent){
    const invalidCharacters = ['.','e','+','E'];
    if(invalidCharacters.includes(event.key)){
      event?.preventDefault();
    }
  }
  
}
