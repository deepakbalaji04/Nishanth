import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { NewTravelRequestComponent } from './components/new-travel-request/new-travel-request.component';
import { NewRequestListComponent } from './components/new-request-list/new-request-list.component';
import { BudgetAllocationComponent } from './components/budget-allocation/budget-allocation.component';
import { TravelRequestDetailsComponent } from './components/travel-request-details/travel-request-details.component';
import { AuthGuardService } from './services/auth-guard.service';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'new', component: NewTravelRequestComponent, canActivate:[AuthGuardService], data:{authorisedRole: 'Employee'} },
  { path: 'pending', component: NewRequestListComponent, canActivate:[AuthGuardService], data:{authorisedRole: 'HR'} },
  { path: 'details', component: TravelRequestDetailsComponent},
  { path: 'pending/:trid/update', component: BudgetAllocationComponent, canActivate:[AuthGuardService], data:{authorisedRole: 'HR'}},
  { path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
