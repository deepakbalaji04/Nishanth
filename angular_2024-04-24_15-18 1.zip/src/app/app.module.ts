import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NewTravelRequestComponent } from './components/new-travel-request/new-travel-request.component';
import { NewRequestListComponent } from './components/new-request-list/new-request-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { BudgetAllocationComponent } from './components/budget-allocation/budget-allocation.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { TravelRequestDetailsComponent } from './components/travel-request-details/travel-request-details.component';
import { AuthenticationService } from './services/authentication.service';
import { AuthGuardService } from './services/auth-guard.service';
import { TravelRequestService } from './services/travel-request.service';

@NgModule({
    declarations: [
        AppComponent,
        NewTravelRequestComponent,
        NewRequestListComponent,
        BudgetAllocationComponent,
        NavbarComponent,
        HomeComponent,
        TravelRequestDetailsComponent
    ],
    providers: [AuthenticationService, AuthGuardService, TravelRequestService],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MatButtonModule,
        MatTableModule,
        MatPaginatorModule,
        HttpClientModule,
        NgxPaginationModule
    ]
})
export class AppModule { }
