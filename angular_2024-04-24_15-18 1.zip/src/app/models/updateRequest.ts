export interface UpdateRequest{
    requestStatus:String;
}