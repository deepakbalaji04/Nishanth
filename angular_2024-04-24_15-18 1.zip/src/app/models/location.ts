export interface Location {
    locationId: number;
    locationName: String;
}