export interface TravelRequest{
    requestId: number,
    raisedByEmployeeId: number,
    toBeApprovedByHRId: number,
    requestRaisedOn: string,
    fromDate: string,
    toDate: string,
    purposeOfTravel: string,
    locationId: number,
    requestStatus: string,
    requestApprovedOn: string,
    priority: string,
    budgetPerDay: number
}